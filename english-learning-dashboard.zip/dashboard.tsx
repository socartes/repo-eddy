"use client"

import { useState } from "react"
import {
  Bell,
  Book,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Clock,
  MessageCircle,
  Pencil,
  Star,
  Target,
  Video,
} from "lucide-react"
import Link from "next/link"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"

export default function Dashboard() {
  const [activeStudent, setActiveStudent] = useState("Asya")

  return (
    <div className="min-h-screen bg-[#f5f2f4]">
      {/* Navigation Bar */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center justify-between h-16 px-4 mx-auto md:px-6">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-[#470b69]">
              <span className="text-xl font-bold text-white">E</span>
            </div>
            <span className="text-xl font-bold text-[#470b69]">EnglishKids</span>
          </div>

          <nav className="hidden md:flex items-center space-x-6">
            <Link href="#" className="text-[#470b69] font-medium hover:text-[#a38fb2] transition-colors">
              Ana Sayfa
            </Link>
            <Link href="#" className="text-[#470b69] font-medium hover:text-[#a38fb2] transition-colors">
              Ders İşlemleri
            </Link>
            <Link href="#" className="text-[#470b69] font-medium hover:text-[#a38fb2] transition-colors">
              Kütüphane
            </Link>
            <Link href="#" className="text-[#470b69] font-medium hover:text-[#a38fb2] transition-colors">
              Kazanımlar
            </Link>
            <Link href="#" className="text-[#470b69] font-medium hover:text-[#a38fb2] transition-colors">
              Konuşma Pratiği
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              className="hidden md:flex border-[#470b69] text-[#470b69] hover:bg-[#470b69] hover:text-white"
            >
              Bonusu Kapatın
            </Button>
            <Button variant="ghost" size="icon" className="text-[#470b69]">
              <Bell className="w-5 h-5" />
            </Button>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
              <AvatarFallback className="bg-[#a38fb2] text-white">UK</AvatarFallback>
            </Avatar>
            <Button variant="ghost" size="icon" className="md:hidden text-[#470b69]">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-menu"
              >
                <line x1="4" x2="20" y1="12" y2="12" />
                <line x1="4" x2="20" y1="6" y2="6" />
                <line x1="4" x2="20" y1="18" y2="18" />
              </svg>
            </Button>
          </div>
        </div>
      </header>

      <main className="container px-4 py-6 mx-auto md:px-6">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {/* Membership Section */}
          <Card className="col-span-full md:col-span-1 bg-white rounded-xl shadow-sm border-none">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-[#470b69]">Üyelik</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-[#f5f2f4]">
                    <Calendar className="w-5 h-5 text-[#470b69]" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Kalan dersler</p>
                    <p className="text-lg font-semibold text-[#470b69]">2</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-[#f5f2f4]">
                    <Clock className="w-5 h-5 text-[#470b69]" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Otomatik yenileme</p>
                    <p className="text-lg font-semibold text-[#470b69]">10 Nis</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Homework Panel */}
          <Card className="col-span-full md:col-span-1 bg-white rounded-xl shadow-sm border-none">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-[#470b69]">Ödev</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Asya" />
                      <AvatarFallback className="bg-[#a38fb2] text-white">AS</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-[#470b69]">Asya</p>
                      <p className="text-sm text-muted-foreground">1 egzersiz tamamlayın</p>
                    </div>
                  </div>
                  <Button className="bg-[#39ff14] hover:bg-[#39ff14]/80 text-[#470b69] font-medium">Tamamla</Button>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Ertuğ" />
                      <AvatarFallback className="bg-[#a38fb2] text-white">ER</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-[#470b69]">Ertuğ</p>
                      <p className="text-sm text-muted-foreground">Tüm egzersizler tamamlandı</p>
                    </div>
                  </div>
                  <Badge className="bg-[#a38fb2] text-white">Tamamlandı</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Call-to-Action Banner */}
          <Card className="col-span-full md:col-span-1 bg-gradient-to-r from-[#470b69] to-[#a38fb2] text-white rounded-xl shadow-sm border-none">
            <CardContent className="p-6">
              <div className="flex flex-col items-start gap-4">
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-white/20">
                    <MessageCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">Konuşma Grubu</h3>
                    <p className="text-sm text-white/80">Arkadaşlarınızla İngilizce pratik yapın</p>
                  </div>
                </div>
                <div className="flex -space-x-4">
                  {[1, 2, 3, 4].map((i) => (
                    <Avatar key={i} className="border-2 border-[#470b69]">
                      <AvatarImage src={`/placeholder.svg?height=40&width=40&text=${i}`} alt={`User ${i}`} />
                      <AvatarFallback className="bg-[#a38fb2] text-white">{i}</AvatarFallback>
                    </Avatar>
                  ))}
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-white/20 text-white">
                    +8
                  </div>
                </div>
                <Button className="bg-[#39ff14] hover:bg-[#39ff14]/80 text-[#470b69] font-medium">Üye ol</Button>
              </div>
            </CardContent>
          </Card>

          {/* Next Lesson Section */}
          <Card className="col-span-full bg-white rounded-xl shadow-sm border-none">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-[#470b69]">Sonraki Ders</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <ScrollArea className="w-full whitespace-nowrap">
                  <div className="flex space-x-4 p-1">
                    {["Asya", "Ertuğ"].map((student) => (
                      <button
                        key={student}
                        onClick={() => setActiveStudent(student)}
                        className={`flex flex-col items-center space-y-1 ${
                          activeStudent === student ? "opacity-100" : "opacity-60"
                        }`}
                      >
                        <Avatar
                          className={`w-16 h-16 border-2 ${
                            activeStudent === student ? "border-[#39ff14]" : "border-transparent"
                          }`}
                        >
                          <AvatarImage
                            src={`/placeholder.svg?height=64&width=64&text=${student.charAt(0)}`}
                            alt={student}
                          />
                          <AvatarFallback className="bg-[#a38fb2] text-white text-xl">
                            {student.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium text-[#470b69]">{student}</span>
                      </button>
                    ))}
                  </div>
                  <ScrollBar orientation="horizontal" />
                </ScrollArea>
              </div>

              {activeStudent === "Asya" ? (
                <Card className="border border-[#a38fb2]/20 shadow-none">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle className="text-[#470b69]">9 Nis, 18:30</CardTitle>
                        <CardDescription>{activeStudent} ve April H</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-6">
                      {/* Left column - Timeline (50% width) */}
                      <div className="w-1/2 space-y-4">
                        <div className="flex gap-4">
                          <div className="flex flex-col items-center">
                            <div className="w-8 h-8 rounded-full bg-[#a38fb2] flex items-center justify-center text-white">
                              1
                            </div>
                            <div className="w-0.5 h-16 bg-[#a38fb2]/30 my-1"></div>
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium text-[#470b69]">Isınma (~5 dk)</h4>
                            <p className="text-sm text-muted-foreground">Video izleyin ve ısınma egzersizleri yapın.</p>
                            <div className="flex items-center gap-2 mt-2">
                              <div className="w-10 h-10 rounded-lg bg-[#f5f2f4] flex items-center justify-center">
                                <Video className="w-5 h-5 text-[#470b69]" />
                              </div>
                              <Button
                                size="sm"
                                className="bg-[#39ff14] hover:bg-[#39ff14]/80 text-[#470b69] font-medium"
                              >
                                Başla
                              </Button>
                            </div>
                          </div>
                        </div>

                        <div className="flex gap-4">
                          <div className="flex flex-col items-center">
                            <div className="w-8 h-8 rounded-full bg-[#a38fb2] flex items-center justify-center text-white">
                              2
                            </div>
                            <div className="w-0.5 h-16 bg-[#a38fb2]/30 my-1"></div>
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium text-[#470b69]">Ders (~25 dk)</h4>
                            <p className="text-sm text-muted-foreground">Ana ders bölümü</p>
                            <div className="flex items-center gap-2 mt-2">
                              <div className="w-10 h-10 rounded-lg bg-[#f5f2f4] flex items-center justify-center">
                                <Book className="w-5 h-5 text-[#470b69]" />
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="flex gap-4">
                          <div className="flex flex-col items-center">
                            <div className="w-8 h-8 rounded-full bg-[#a38fb2] flex items-center justify-center text-white">
                              3
                            </div>
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium text-[#470b69]">Eğlenceli pratik (~10 dk)</h4>
                            <p className="text-sm text-muted-foreground">Eğlenceli pratik egzersizleri</p>
                            <div className="flex items-center gap-2 mt-2">
                              <div className="w-10 h-10 rounded-lg bg-[#f5f2f4] flex items-center justify-center">
                                <Pencil className="w-5 h-5 text-[#470b69]" />
                              </div>
                            </div>
                          
                        <div className="mt-2">
                          <Button
                            variant="outline"
                            className="border-[#470b69] text-[#470b69] hover:bg-[#470b69] hover:text-white w-full"
                          >
                            Takvime ekle
                          </Button>
                          <Link href="#" className="text-[#470b69] hover:text-[#a38fb2] text-sm font-medium block text-center mt-2">
                            + Ders planla
                          </Link>
                        </div>
                      </div>
                      
                      {/* Right column - Video placeholder (50% width) */}
                      <div className="w-1/2 flex items-center justify-center">
                        <div className="w-full aspect-video bg-[#f5f2f4] rounded-xl flex items-center justify-center">
                          <Video className="w-12 h-12 text-[#a38fb2] opacity-50" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="border border-[#a38fb2]/20 shadow-none">
                  <CardContent className="pt-6 pb-4 flex flex-col items-center justify-center text-center">
                    <div className="w-16 h-16 rounded-full bg-[#f5f2f4] flex items-center justify-center mb-4">
                      <Calendar className="w-8 h-8 text-[#a38fb2]" />
                    </div>
                    <p className="text-lg font-medium text-[#470b69] mb-6">Bir sonraki ders henüz planlanmadı</p>
                    <Button
                      variant="outline"
                      className="mb-4 border-[#470b69] text-[#470b69] hover:bg-[#470b69] hover:text-white"
                    >
                      + Ders planla
                    </Button>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>

          {/* Recent Activities Section */}
          <Card className="col-span-full bg-white rounded-xl shadow-sm border-none">
            <CardHeader className="flex flex-row items-centerr justify-between pb-2">
              <CardTitle className="text-lg text-[#470b69]">Son Aktiviteler</CardTitle>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" className="text-[#470b69]">
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="text-[#470b69]">
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="bg-[#f5f2f4] p-4 rounded-xl">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Asya" />
                        <AvatarFallback className="bg-[#a38fb2] text-white">AS</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-[#470b69]">Asya</p>
                        <p className="text-xs text-muted-foreground">Öğretmen: April H • 7 Nis</p>
                      </div>
                    </div>
                    <Badge className="bg-[#470b69]">Magic Academy Quest 3</Badge>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Star className="w-4 h-4 text-[#470b69]" />
                        <h4 className="font-medium text-[#470b69]">Başarı Alanları</h4>
                      </div>
                      <p className="text-sm text-muted-foreground pl-6">
                        Asya, yeni kelimeleri çok iyi hatırlıyor ve doğru telaffuz ediyor. Soru-cevap aktivitelerinde
                        çok başarılı.
                      </p>
                    </div>

                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Target className="w-4 h-4 text-[#470b69]" />
                        <h4 className="font-medium text-[#470b69]">Öğretmen Önerileri</h4>
                      </div>
                      <p className="text-sm text-muted-foreground pl-6">
                        Daha fazla okuma pratiği yapması ve yeni öğrendiği kelimeleri cümle içinde kullanması faydalı
                        olacaktır.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-[#f5f2f4] p-4 rounded-xl">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Ertuğ" />
                        <AvatarFallback className="bg-[#a38fb2] text-white">ER</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-[#470b69]">Ertuğ</p>
                        <p className="text-xs text-muted-foreground">Öğretmen: Sarah K • 5 Nis</p>
                      </div>
                    </div>
                    <Badge className="bg-[#470b69]">Space Adventure 2</Badge>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Star className="w-4 h-4 text-[#470b69]" />
                        <h4 className="font-medium text-[#470b69]">Başarı Alanları</h4>
                      </div>
                      <p className="text-sm text-muted-foreground pl-6">
                        Ertuğ, konuşma aktivitelerinde çok aktif ve yaratıcı. Hikaye anlatımında harika bir ilerleme
                        gösterdi.
                      </p>
                    </div>

                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Target className="w-4 h-4 text-[#470b69]" />
                        <h4 className="font-medium text-[#470b69]">Öğretmen Önerileri</h4>
                      </div>
                      <p className="text-sm text-muted-foreground pl-6">
                        Yazma becerilerini geliştirmek için günlük tutması ve öğrendiği yeni yapıları yazıda kullanması
                        önerilir.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
