"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { Loader2 } from "lucide-react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"

export default function VerifyPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()

  const contactMethod = searchParams.get("method") || "phone"
  const contactValue = searchParams.get("value") || ""

  const [isLoading, setIsLoading] = useState(false)
  const [verificationCode, setVerificationCode] = useState(["", "", "", "", "", ""])
  const [timeLeft, setTimeLeft] = useState(120) // 2 minutes in seconds
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  // Format the contact value for display
  const displayContact = contactMethod === "phone" ? `+90${contactValue}` : contactValue

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  // Handle countdown timer
  useEffect(() => {
    if (timeLeft <= 0) return

    const timer = setTimeout(() => {
      setTimeLeft(timeLeft - 1)
    }, 1000)

    return () => clearTimeout(timer)
  }, [timeLeft])

  // Handle input change
  const handleInputChange = (index: number, value: string) => {
    // Only allow numbers
    if (value && !/^\d+$/.test(value)) return

    // Update the code array
    const newCode = [...verificationCode]
    newCode[index] = value
    setVerificationCode(newCode)

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus()
    }
  }

  // Handle key down for backspace
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && !verificationCode[index] && index > 0) {
      inputRefs.current[index - 1]?.focus()
    }
  }

  // Handle paste
  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault()
    const pastedData = e.clipboardData.getData("text")

    // Check if pasted content is a 6-digit number
    if (/^\d{6}$/.test(pastedData)) {
      const digits = pastedData.split("")
      setVerificationCode(digits)

      // Focus the last input
      inputRefs.current[5]?.focus()
    }
  }

  // Handle resend code
  const handleResendCode = async () => {
    setIsLoading(true)

    try {
      // This would be replaced with actual API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Reset timer
      setTimeLeft(120)

      toast({
        title: "Kod yeniden gönderildi",
        description: "Lütfen telefonunuzu kontrol edin.",
      })
    } catch (error) {
      toast({
        title: "Hata",
        description: "Kod gönderilirken bir hata oluştu. Lütfen tekrar deneyin.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Handle verify code
  const handleVerifyCode = async () => {
    // Check if code is complete
    if (verificationCode.some((digit) => !digit)) {
      toast({
        title: "Eksik kod",
        description: "Lütfen 6 haneli kodu tam olarak girin.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // This would be replaced with actual API call
      const code = verificationCode.join("")

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // For demo purposes, any code is valid except "000000"
      if (code === "000000") {
        throw new Error("Geçersiz kod. Lütfen tekrar deneyin.")
      }

      toast({
        title: "Doğrulama başarılı!",
        description: "Giriş yapılıyor...",
      })

      // Redirect to home page
      router.push("/")
    } catch (error) {
      toast({
        title: "Hata",
        description: error instanceof Error ? error.message : "Doğrulama sırasında bir hata oluştu",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <Image src="/images/yeni-logo.png" alt="Eddy Logo" width={180} height={60} priority />
        </div>

        {/* Verification Card */}
        <div className="bg-white rounded-xl shadow-md p-8">
          <h1 className="text-2xl font-bold text-center mb-6 text-gray-800">Neredeyse bitti!</h1>

          <p className="text-center text-gray-600 mb-6">
            Lütfen <span className="font-medium">{displayContact}</span> numarasına gönderdiğimiz kodu girin
          </p>

          {/* Code input fields */}
          <div className="flex justify-center gap-2 mb-6">
            {verificationCode.map((digit, index) => (
              <input
                key={index}
                ref={(el) => (inputRefs.current[index] = el)}
                type="text"
                maxLength={1}
                value={digit}
                onChange={(e) => handleInputChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                onPaste={index === 0 ? handlePaste : undefined}
                className="w-12 h-12 text-center text-xl font-medium border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#470b69] focus:border-transparent"
                disabled={isLoading}
              />
            ))}
          </div>

          {/* Resend code button */}
          <Button
            type="button"
            variant="outline"
            className="w-full h-12 mb-4"
            onClick={handleResendCode}
            disabled={isLoading || timeLeft > 0}
          >
            {isLoading ? <Loader2 className="h-5 w-5 animate-spin mr-2" /> : null}
            Kodu yeniden gönder {timeLeft > 0 ? formatTime(timeLeft) : ""}
          </Button>

          {/* Verify button */}
          <Button
            type="button"
            className="w-full bg-[#470b69] hover:bg-[#5c1b85] h-12 mb-4"
            onClick={handleVerifyCode}
            disabled={isLoading || verificationCode.some((digit) => !digit)}
          >
            {isLoading ? <Loader2 className="h-5 w-5 animate-spin mr-2" /> : null}
            Doğrula
          </Button>

          {/* Try different method */}
          <div className="text-center">
            <Link href="/auth/login" className="text-[#470b69] text-sm hover:underline">
              Farklı bir e-posta/telefon ile giriş yapın
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
