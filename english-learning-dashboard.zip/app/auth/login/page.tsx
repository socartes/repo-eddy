"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ChevronDown, Loader2 } from "lucide-react"
import { z } from "zod"
import Image from "next/image"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"

// Form validation schemas
const emailSchema = z.object({
  email: z.string().email({ message: "Geçerli bir e-posta adresi giriniz" }),
})

const phoneSchema = z.object({
  phone: z.string().length(10, { message: "Telefon numarası 10 haneli olmalıdır" }),
})

export default function LoginPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [loginMethod, setLoginMethod] = useState<"email" | "phone">("phone")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [error, setError] = useState<string | null>(null)

  // Şifre ile giriş yapmak için state ekleyelim
  const [showPasswordField, setShowPasswordField] = useState(false)
  const [password, setPassword] = useState("")

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value)
    setError(null)
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPhone(e.target.value)
    setError(null)
  }

  // handlePasswordChange fonksiyonunu ekleyelim
  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value)
    setError(null)
  }

  const handleGoogleLogin = async () => {
    // Hiçbir şey yapma
  }

  const handleAppleLogin = async () => {
    // Hiçbir şey yapma
  }

  // handleSubmit fonksiyonunu güncelleyelim - şifre kontrolü ekleyelim
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Şifre ile giriş yapılıyorsa
      if (showPasswordField && password) {
        // Şifre doğrulama işlemi
        const response = await fetch("/api/auth/login/password", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email: loginMethod === "email" ? email : undefined,
            phone: loginMethod === "phone" ? phone : undefined,
            password,
          }),
        })

        const data = await response.json()

        if (!response.ok) {
          throw new Error(data.message || "Giriş sırasında bir hata oluştu")
        }

        // Başarılı giriş
        toast({
          title: "Giriş başarılı!",
          description: "Hoş geldiniz.",
        })

        // Doğrudan ana sayfaya yönlendir
        router.push("/")
        return
      }

      // Şifre ile giriş yapılmıyorsa, doğrulama kodu sayfasına yönlendir
      if (loginMethod === "email") {
        // Validate email
        emailSchema.parse({ email })

        // Doğrulama sayfasına yönlendir
        router.push(`/auth/verify?method=email&value=${encodeURIComponent(email)}`)
      } else {
        // Validate phone
        phoneSchema.parse({ phone })

        // Doğrulama sayfasına yönlendir
        router.push(`/auth/verify?method=phone&value=${encodeURIComponent(phone)}`)
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        // Handle validation errors
        setError(error.errors[0].message)

        toast({
          title: "Form hatası",
          description: error.errors[0].message,
          variant: "destructive",
        })
      } else {
        // Handle other errors
        setError(error instanceof Error ? error.message : "Giriş sırasında bir hata oluştu")

        toast({
          title: "Hata",
          description: error instanceof Error ? error.message : "Giriş sırasında bir hata oluştu",
          variant: "destructive",
        })
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-4">
          <Image src="/images/yeni-logo.png" alt="Eddy Logo" width={180} height={60} priority />
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-xl shadow-md p-8">
          <h1 className="text-2xl font-bold text-center mb-6 text-gray-800">Tekrar hoş geldiniz!</h1>

          {/* Login Method Tabs */}
          <Tabs
            defaultValue="phone"
            className="mb-6"
            onValueChange={(value) => setLoginMethod(value as "email" | "phone")}
          >
            <TabsList className="grid w-full grid-cols-2 bg-gray-100 rounded-full">
              <TabsTrigger className="rounded-full data-[state=active]:rounded-full" value="email">
                E-posta
              </TabsTrigger>
              <TabsTrigger className="rounded-full data-[state=active]:rounded-full" value="phone">
                Telefon
              </TabsTrigger>
            </TabsList>

            <TabsContent value="email" className="mt-4">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Input
                    type="email"
                    placeholder="E-posta adresiniz"
                    value={email}
                    onChange={handleEmailChange}
                    className={error ? "border-red-500" : ""}
                    disabled={isLoading}
                    autoComplete="email"
                    name="email"
                  />
                  {error && <p className="text-red-500 text-sm mt-1 mb-0">{error}</p>}
                </div>

                {showPasswordField && (
                  <div className="mt-2">
                    <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                      Şifreniz
                    </label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="Şifrenizi girin"
                      value={password}
                      onChange={handlePasswordChange}
                      className={error ? "border-red-500" : ""}
                      disabled={isLoading}
                      autoComplete="current-password"
                      name="password"
                    />
                  </div>
                )}

                <div className="pt-4">
                  <Button
                    type="submit"
                    className="w-full bg-[#470b69] hover:bg-[#5c1b85] text-white h-12"
                    disabled={isLoading}
                  >
                    {isLoading ? <Loader2 className="h-5 w-5 animate-spin mr-2" /> : null}
                    {showPasswordField ? "Giriş Yap" : "Devam et"}
                  </Button>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="phone" className="mt-4">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <div className="flex">
                    <div className="flex items-center justify-center bg-gray-100 px-3 rounded-l-md border border-r-0 border-gray-300">
                      <div className="flex items-center gap-1">
                        <img src="https://flagcdn.com/w20/tr.png" alt="Turkey" className="h-4" />
                        <span className="text-sm">+90</span>
                        <ChevronDown className="h-4 w-4 text-gray-500" />
                      </div>
                    </div>
                    <Input
                      type="tel"
                      placeholder="Telefon numaranız"
                      value={phone}
                      onChange={handlePhoneChange}
                      className={`rounded-l-none ${error ? "border-red-500" : ""}`}
                      disabled={isLoading}
                    />
                  </div>
                  {error && <p className="text-red-500 text-sm mt-1 mb-0">{error}</p>}
                </div>

                {showPasswordField && (
                  <div className="mt-2">
                    <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                      Şifreniz
                    </label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="Şifrenizi girin"
                      value={password}
                      onChange={handlePasswordChange}
                      className={error ? "border-red-500" : ""}
                      disabled={isLoading}
                      autoComplete="current-password"
                      name="password"
                    />
                  </div>
                )}

                <div className="pt-4">
                  <Button
                    type="submit"
                    className="w-full bg-[#470b69] hover:bg-[#5c1b85] text-white h-12"
                    disabled={isLoading}
                  >
                    {isLoading ? <Loader2 className="h-5 w-5 animate-spin mr-2" /> : null}
                    {showPasswordField ? "Giriş Yap" : "Devam et"}
                  </Button>
                </div>
              </form>
            </TabsContent>
          </Tabs>

          {/* Şifre ile giriş bağlantısını güncelleyelim - Link yerine button kullanacağız */}
          <div className="text-center mb-6">
            <button
              onClick={() => setShowPasswordField(!showPasswordField)}
              className="text-[#470b69] text-sm font-medium hover:underline"
            >
              {showPasswordField ? "Kod ile giriş yap" : "Şifre ile giriş yap"}
            </button>
          </div>

          <div className="relative flex items-center justify-center mb-6">
            <div className="border-t border-gray-300 flex-grow"></div>
            <span className="px-3 text-gray-500 text-sm">Veya devam etmek için seçin:</span>
            <div className="border-t border-gray-300 flex-grow"></div>
          </div>

          {/* Social Login Buttons */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <Button
              type="button"
              variant="outline"
              className="flex items-center justify-center gap-2 h-12 hover:bg-[#470b69]/10"
              onClick={handleAppleLogin}
              disabled={isLoading}
            >
              <div className="w-7 h-7 flex items-center justify-center">
                <svg viewBox="0 0 24 24" width="40" height="40" fill="currentColor">
                  <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" />
                </svg>
              </div>
            </Button>

            <Button
              type="button"
              variant="outline"
              className="flex items-center justify-center gap-2 h-12 hover:bg-[#470b69]/10"
              onClick={handleGoogleLogin}
              disabled={isLoading}
            >
              <div className="w-7 h-7 flex items-center justify-center">
                <svg viewBox="0 0 24 24" width="40" height="40">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
              </div>
            </Button>
          </div>

          <div className="text-center">
            <p className="text-sm">
              Hesabınız yok mu?{" "}
              <Link href="/auth/signup" className="text-[#ffcc00] font-medium underline">
                Kaydol
              </Link>
            </p>
          </div>
        </div>

        {/* App Store Links kaldırıldı */}
      </div>
    </div>
  )
}
