"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Search, ChevronDown } from "lucide-react"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function HelpCenterPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [language, setLanguage] = useState<"Türkçe" | "İngilizce">("Türkçe")

  const helpCategories = [
    {
      icon: "✏️",
      title: "Ders programınızı düzenleyin",
      description: "Planlama, taşıma ve iptal seçenekleri de dahil olmak üzere ders programını yönetme.",
      author: "Astro",
      articles: 6,
    },
    {
      icon: "💬",
      title: "Üyelikler, Ödemeler ve Bonuslar",
      description: "Abonelik türleri, ödemeler, hesap ve bonus bakiyesi",
      author: "Astro",
      articles: 17,
    },
    {
      icon: "📚",
      title: "Derse nasıl hazırlanır?",
      description: "Teknik öneriler, bağlantı sorunlarını çözme ve diğer ders gereksinimleri",
      author: "Astro",
      articles: 3,
    },
    {
      icon: "🏆",
      title: "Metodoloji",
      description: "EddyKids programı, seviyeler, ilerleme ve ödevler hakkında",
      author: "Astro",
      articles: 2,
    },
    {
      icon: "👩‍🏫",
      title: "Öğretmenler",
      description: "Yedek öğretmen seçeneği de dahil olmak üzere EddyKids öğretmen tercihlerinizi yönetme.",
      author: "Astro",
      articles: 2,
    },
    {
      icon: "🚀",
      title: "EddyKids hesabınız",
      description: "Hesabınıza yönelik rehberlik, ayarlar ve kişisel bilgilerin yönetilmesi",
      author: "Astro",
      articles: 4,
    },
    {
      icon: "🌍",
      title: "World Kids Academy (Uluslar arası gruplarda konuşma dersleri)",
      description:
        "Konuşma Grup Derslerini Keşfedin; Bu derslere kimlerin katılabileceği, nasıl rezervasyon yaptırılacağı ve...",
      author: "Astro",
      articles: 7,
    },
    {
      icon: "⚡",
      title: "Kış Yarışması",
      description: "",
      author: "Astro ve 1 diğer",
      articles: 2,
    },
  ]

  return (
    <div className="min-h-screen">
      <div className="bg-[#9333ea] text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <Link href="/" className="text-white">
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </div>
            <div className="flex items-center gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center gap-1">
                  <span>{language}</span>
                  <ChevronDown className="h-4 w-4" />
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setLanguage("Türkçe")}>Türkçe</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLanguage("İngilizce")}>İngilizce</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
          <h1 className="text-2xl font-bold mb-6">EddyKids Ekibinden tavsiyeler ve yanıtlar</h1>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Makale ara..."
              className="pl-10 bg-white/20 border-none text-white placeholder:text-white/70 rounded-lg"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="grid gap-4">
          {helpCategories.map((category, index) => (
            <div
              key={index}
              className="border rounded-lg p-4 flex items-start gap-4 hover:shadow-md transition-shadow cursor-pointer"
            >
              <div className="w-12 h-12 bg-[#f5f2f4] rounded-lg flex items-center justify-center text-2xl">
                {category.icon}
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-[#470b69] mb-1">{category.title}</h3>
                <p className="text-sm text-gray-600 mb-2">{category.description}</p>
                <div className="flex items-center text-xs text-gray-500">
                  <span>Yazar: {category.author}</span>
                  <span className="mx-2">•</span>
                  <span>{category.articles} makale</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
