import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function AsyaProfilePage() {
  return (
    <div className="min-h-screen bg-pink-100">
      <div className="container px-4 py-8 mx-auto">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" className="flex items-center gap-2 text-[#470b69]">
              <ArrowLeft size={16} />
              Ana Sayfaya Dön
            </Button>
          </Link>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-8 mb-6">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
            <div className="w-32 h-32 rounded-full overflow-hidden bg-pink-200 flex items-center justify-center">
              <img
                src="/placeholder.svg?height=128&width=128&text=A"
                alt="Asya"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex-1 text-center md:text-left">
              <h1 className="text-3xl font-bold text-[#470b69] mb-2">Asya</h1>
              <p className="text-lg text-gray-600 mb-4">Öğrenci Profili</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="bg-pink-50 p-4 rounded-lg">
                  <h3 className="font-medium text-[#470b69] mb-1">Seviye</h3>
                  <p className="text-lg">Başlangıç (A1)</p>
                </div>
                <div className="bg-pink-50 p-4 rounded-lg">
                  <h3 className="font-medium text-[#470b69] mb-1">Tamamlanan Dersler</h3>
                  <p className="text-lg">24</p>
                </div>
                <div className="bg-pink-50 p-4 rounded-lg">
                  <h3 className="font-medium text-[#470b69] mb-1">Yaş</h3>
                  <p className="text-lg">8</p>
                </div>
                <div className="bg-pink-50 p-4 rounded-lg">
                  <h3 className="font-medium text-[#470b69] mb-1">Katılım Tarihi</h3>
                  <p className="text-lg">15 Oca 2023</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button className="bg-[#470b69] hover:bg-[#470b69]/80">Ders Planla</Button>
                <Button
                  variant="outline"
                  className="border-[#470b69] text-[#470b69] hover:bg-[#470b69] hover:text-white"
                >
                  İlerleme Raporu
                </Button>
                <Button
                  variant="outline"
                  className="border-[#470b69] text-[#470b69] hover:bg-[#470b69] hover:text-white"
                >
                  Ödevleri Görüntüle
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <h2 className="text-xl font-bold text-[#470b69] mb-4">Asya'nın İlgi Alanları</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-pink-50 p-4 rounded-lg flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-pink-200 flex items-center justify-center">
                <img src="/placeholder.svg?height=30&width=30&text=🎨" alt="Art" className="w-8 h-8" />
              </div>
              <span className="font-medium">Sanat ve El İşleri</span>
            </div>
            <div className="bg-pink-50 p-4 rounded-lg flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-pink-200 flex items-center justify-center">
                <img src="/placeholder.svg?height=30&width=30&text=🐱" alt="Animals" className="w-8 h-8" />
              </div>
              <span className="font-medium">Hayvanlar</span>
            </div>
            <div className="bg-pink-50 p-4 rounded-lg flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-pink-200 flex items-center justify-center">
                <img src="/placeholder.svg?height=30&width=30&text=🎵" alt="Music" className="w-8 h-8" />
              </div>
              <span className="font-medium">Müzik</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-bold text-[#470b69] mb-4">Öğrenme Hedefleri</h2>
          <ul className="space-y-3">
            <li className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center text-green-600">✓</div>
              <span>Temel selamlaşma ve tanışma ifadelerini öğrenmek</span>
            </li>
            <li className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center text-green-600">✓</div>
              <span>Hayvan isimlerini öğrenmek</span>
            </li>
            <li className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-yellow-100 flex items-center justify-center text-yellow-600">
                ⋯
              </div>
              <span>Basit cümleler kurabilmek</span>
            </li>
            <li className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-gray-600">○</div>
              <span>Kısa hikayeleri anlayabilmek</span>
            </li>
            <li className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-gray-600">○</div>
              <span>Basit sorular sorabilmek ve cevap verebilmek</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}
