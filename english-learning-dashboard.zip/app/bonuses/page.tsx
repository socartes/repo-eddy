"use client"

import { useState } from "react"
import Link from "next/link"
import { Plus } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Image from "next/image"
import { useRouter } from "next/navigation"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { User, HelpCircle, CreditCard, Gift, LogOut } from "lucide-react"

export default function BonusesPage() {
  const [referralLink, setReferralLink] = useState("https://www.novakid.com.tr/r/hc7qa?utm_r")

  const copyToClipboard = () => {
    navigator.clipboard
      .writeText(referralLink)
      .then(() => {
        alert("Bağlantı kopyalandı!")
      })
      .catch((err) => {
        console.error("Kopyalama başarısız oldu:", err)
      })
  }

  const router = useRouter()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [showAddStudentModal, setShowAddStudentModal] = useState(false)
  const [showMembershipDetails, setShowMembershipDetails] = useState(false)

  return (
    <div className="min-h-screen bg-white">
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center justify-between h-16 px-4 mx-auto md:px-6">
          {/* Logo bölümünü değiştir */}
          <div className="flex items-center gap-2">
            <Image src="/images/yeni-logo.png" alt="Eddy Logo" width={120} height={40} priority />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-4 lg:space-x-6">
            {["Ana Sayfa", "Ders İşlemleri", "Kütüphane", "Kazanımlar", "Konuşma Pratiği"].map((page) => (
              <Link
                key={page}
                href="#"
                className={`text-[#470b69] font-medium hover:text-[#a38fb2] transition-colors relative py-1 ${
                  page === "Ana Sayfa" ? "" : ""
                }`}
              >
                {page}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2 md:gap-4">
            <Button
              variant="outline"
              className="hidden md:flex border-[#470b69] text-[#470b69] hover:bg-[#470b69] hover:text-white text-sm whitespace-nowrap"
              onClick={() => router.push("/bonuses")}
            >
              Bonusu Kapın
            </Button>

            {/* Student Avatars */}
            <div className="hidden md:flex -space-x-2 mr-1">
              <Avatar className="border-2 border-white cursor-pointer" onClick={() => router.push("/student/asya")}>
                <AvatarImage src="/placeholder.svg?height=32&width=32&text=A" alt="Asya" />
                <AvatarFallback className="bg-[#a38fb2] text-white">A</AvatarFallback>
              </Avatar>
              <Avatar className="border-2 border-white cursor-pointer" onClick={() => router.push("/student/ertug")}>
                <AvatarImage src="/placeholder.svg?height=32&width=32&text=E" alt="Ertuğ" />
                <AvatarFallback className="bg-[#a38fb2] text-white">E</AvatarFallback>
              </Avatar>
            </div>

            {/* User Profile Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Avatar className="cursor-pointer">
                  <AvatarImage src="/placeholder.svg?height=40&width=40&text=FH" alt="User" />
                  <AvatarFallback className="bg-[#a38fb2] text-white">FH</AvatarFallback>
                </Avatar>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-base font-medium">Fatma Hacıoğlu</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem className="py-2 cursor-pointer" onClick={() => router.push("/student/ertug")}>
                    <Avatar className="mr-2 h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32&text=E" alt="Ertuğ" />
                      <AvatarFallback className="bg-[#a38fb2] text-white">E</AvatarFallback>
                    </Avatar>
                    <span className="text-gray-600">Ertuğ</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="py-2 cursor-pointer" onClick={() => router.push("/student/asya")}>
                    <Avatar className="mr-2 h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32&text=A" alt="Asya" />
                      <AvatarFallback className="bg-[#a38fb2] text-white">A</AvatarFallback>
                    </Avatar>
                    <span className="text-gray-600">Asya</span>
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem className="py-2" onClick={() => setShowAddStudentModal(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    <span>Öğrenci ekle</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="py-2" onClick={() => router.push("/account")}>
                    <User className="mr-2 h-4 w-4" />
                    <span>Hesap</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="py-2" onClick={() => setShowMembershipDetails(true)}>
                    <CreditCard className="mr-2 h-4 w-4" />
                    <span>Üyelik</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="py-2" onClick={() => router.push("/bonuses")}>
                    <Gift className="mr-2 h-4 w-4" />
                    <span>Bonuslar</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="py-2" onClick={() => router.push("/help")}>
                    <HelpCircle className="mr-2 h-4 w-4" />
                    <span>Yardım</span>
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="py-2" onClick={() => router.push("/auth/login")}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Oturumu kapat</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-[#470b69]"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-x"
                >
                  <path d="M18 6 6 18" />
                  <path d="m6 6 12 12" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-menu"
                >
                  <line x1="4" x2="20" y1="12" y2="12" />
                  <line x1="4" x2="20" y1="6" y2="6" />
                  <line x1="4" x2="20" y1="18" y2="18" />
                </svg>
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="container px-4 py-3">
              <nav className="flex flex-col space-y-3">
                {["Ana Sayfa", "Ders İşlemleri", "Kütüphane", "Kazanımlar", "Konuşma Pratiği"].map((page) => (
                  <Link
                    key={page}
                    href="#"
                    className={`text-[#470b69] font-medium hover:text-[#a38fb2] transition-colors py-1 ${
                      page === "Ana Sayfa" ? "font-bold" : ""
                    }`}
                    onClick={() => {
                      setMobileMenuOpen(false)
                    }}
                  >
                    {page}
                  </Link>
                ))}
                <Button
                  variant="outline"
                  className="border-[#470b69] text-[#470b69] hover:bg-[#470b69] hover:text-white w-full mt-2"
                  onClick={() => router.push("/bonuses")}
                >
                  Bonusu Kapın
                </Button>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-sm text-gray-600">Öğrenciler:</span>
                  <div className="flex gap-2">
                    <Avatar className="cursor-pointer h-8 w-8" onClick={() => router.push("/student/asya")}>
                      <AvatarImage src="/placeholder.svg?height=32&width=32&text=A" alt="Asya" />
                      <AvatarFallback className="bg-[#a38fb2] text-white">A</AvatarFallback>
                    </Avatar>
                    <Avatar className="cursor-pointer h-8 w-8" onClick={() => router.push("/student/ertug")}>
                      <AvatarImage src="/placeholder.svg?height=32&width=32&text=E" alt="Ertuğ" />
                      <AvatarFallback className="bg-[#a38fb2] text-white">E</AvatarFallback>
                    </Avatar>
                  </div>
                </div>
              </nav>
            </div>
          </div>
        )}
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Arkadaşlarınızı EddyKids'e davet edin!</h2>

            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-[#470b69] font-bold">
                  1
                </div>
                <div>
                  <p className="font-medium mb-2">Referans bağlantınızı bir arkadaşınızla paylaşın.</p>
                  <div className="text-sm text-gray-600 mb-3">Bağlantı aracılığıyla bir arkadaşınızı davet edin</div>
                  <div className="flex">
                    <Input value={referralLink} readOnly className="rounded-r-none border-r-0" />
                    <Button className="rounded-l-none bg-[#470b69]" onClick={copyToClipboard}>
                      kopyala
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-[#470b69] font-bold">
                  2
                </div>
                <div>
                  <p className="font-medium mb-2">
                    Arkadaşınız bağlantı aracılığıyla kaydolur ve bir bonus kazanır: deneme dersini tamamladıktan sonra
                    hesabına ₺600 eklenir.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-[#470b69] font-bold">
                  3
                </div>
                <div>
                  <p className="font-medium mb-2">
                    Arkadaşınız deneme dersini başarıyla tamamladığında ₺300 ve ilk alımını yaptığında ₺300 bonus
                    hesabınıza eklenir. Sonrasında satın aldıkları her üyelik tutarının % 5 kadarı bonus kazanmaya devam
                    edersiniz!
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#f5f2f4] p-6 rounded-lg">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-[#470b69] rounded-full flex items-center justify-center text-white">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-user"
                >
                  <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
              </div>
              <h2 className="text-xl font-bold text-[#470b69]">
                ARKADAŞLARINIZI EDDYKIDS'E DAVET EDİN VE AVANTAJLARIN TADINI ÇIKARIN!
              </h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-start gap-2">
                <div className="text-yellow-500 text-xl">★</div>
                <p>
                  Üyelik satın alırken tutarın <span className="font-bold">% 25 oranına kadar</span> tasarruf etmek için
                  bonusları kullanın
                </p>
              </div>
              <div className="flex items-start gap-2">
                <div className="text-yellow-500 text-xl">★</div>
                <p>
                  İstediğiniz kadar arkadaşınıza referans olabilirsiniz. Kazanabileceğiniz bonuslarla ilgili herhangi
                  bir sınır yok!
                </p>
              </div>
            </div>

            <div className="mt-8 p-4 bg-white rounded-lg">
              <p className="text-center text-gray-600">Henüz herhangi bir bonus işleminiz bulunmamaktadır.</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
