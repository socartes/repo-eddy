"use client"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  ThumbsUp,
  ThumbsDown,
  ChevronLeft,
  ChevronRight,
  Share2,
  Heart,
  Languages,
  Play,
  Volume2,
  Maximize2,
  Settings,
  Subtitles,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Facebook, Twitter, Linkedin } from "lucide-react"

export default function LessonDetailsPage({ params }: { params: { id: string } }) {
  const [liked, setLiked] = useState(false)
  const [disliked, setDisliked] = useState(false)
  const [hearted, setHearted] = useState(false)
  const [currentSlide, setCurrentSlide] = useState(0)
  const [currentContentSlide, setCurrentContentSlide] = useState(0)
  const [showFullText, setShowFullText] = useState(false)
  const [showShareDialog, setShowShareDialog] = useState(false)
  const [showTurkishTranslation, setShowTurkishTranslation] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [showRecordingDialog, setShowRecordingDialog] = useState(false)
  const videoProgressRef = useRef<HTMLDivElement>(null)
  const [videoProgress, setVideoProgress] = useState(0)
  const [videoTime, setVideoTime] = useState("01:42")
  const router = useRouter()
  const [currentShareUrl, setCurrentShareUrl] = useState("")

  // Content slides data
  const contentSlides = [
    {
      image: "/placeholder.svg?height=400&width=800&text=Book+2+Chapter+2+Unit+3",
      title: "Book 2, Chapter 2, Unit 3",
      subtitle: "Astro the balloon",
      description: "Quest 3: Animals Letter sounds ur/or/ure",
    },
    {
      image: "/placeholder.svg?height=400&width=800&text=Animals+Vocabulary",
      title: "Animals Vocabulary",
      subtitle: "Learn new words",
      description: "Tiger, Zebra, Giraffe, Crocodile, Rhino, Monkey",
    },
    {
      image: "/placeholder.svg?height=400&width=800&text=Letter+Sounds",
      title: "Letter Sounds",
      subtitle: "Practice pronunciation",
      description: "ur, or, ure sounds and examples",
    },
  ]

  // This would normally come from an API or database
  const lessonData = {
    id: params.id,
    title: "Magic Academy Quest 3: Astro, the balloon - Animals Letter sounds ur/or/ure",
    date: "02 Nisan",
    time: "18:30 - 19:00",
    student: "Asya",
    teacher: "April H",
    hasRecording: true,
    lessonType: "Magic Academy Quest 3",
    content: `Hello, Asya! It was lovely to see you in class today. Thank you for all of your hard work. Keep it up!`,
    areasOfSuccess: `You managed to practice the use of can/can't with action verbs, learn the vocabulary words for sports (football, volleyball, badminton, basketball), learn the vocabulary words for animals (tiger, zebra, giraffe, crocodile, rhino, monkey, elephant, snake), talk about your favourites using 'My favourite ... is ... .' and 'I like ... ', play out the dialogues with the teacher`,
    teacherRecommendations: `Please continue to practice on recognizing and saying the letters 'ur', 'or', and 'ure', and read words with them, blending words using the letters 'ur', 'or' and 'ure'. Well done for today! 💗✨`,
    // Turkish translations
    contentTR: `Merhaba, Asya! Bugün seni sınıfta görmek harikaydı. Tüm çalışmaların için teşekkür ederim. Böyle devam et!`,
    areasOfSuccessTR: `Can/can't fiillerini eylem fiilleriyle birlikte kullanmayı, spor kelimelerini (futbol, voleybol, badminton, basketbol), hayvan kelimelerini (kaplan, zebra, zürafa, timsah, gergedan, maymun, fil, yılan) öğrenmeyi, 'En sevdiğim ... ... .' ve 'Ben ... severim' kalıplarını kullanarak favorilerinden bahsetmeyi, öğretmenle diyalogları canlandırmayı başardın.`,
    teacherRecommendationsTR: `Lütfen 'ur', 'or' ve 'ure' harflerini tanıma ve söyleme pratiği yapmaya devam et ve bunlarla kelimeler oku, 'ur', 'or' ve 'ure' harflerini kullanarak kelimeleri birleştir. Bugün için harika iş çıkardın! 💗✨`,
    imageUrl: "/placeholder.svg?height=400&width=800&text=Lesson+Screenshot",
    teacherImageUrl: "/placeholder.svg?height=60&width=60&text=AH",
    completedExercises: 14,
    totalExercises: 14,
    shareUrl: "https://www.novakid.com.tr/card?id=1tzFjyfZQRKss1RhQl",
  }

  const handleLike = () => {
    setLiked(!liked)
    if (disliked) setDisliked(false)
  }

  const handleDislike = () => {
    setDisliked(!disliked)
    if (liked) setLiked(false)
  }

  const handleHeart = () => {
    setHearted(!hearted)
  }

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % 5) // Assuming 5 slides
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + 5) % 5) // Assuming 5 slides
  }

  const nextContentSlide = () => {
    setCurrentContentSlide((prev) => (prev + 1) % contentSlides.length)
  }

  const prevContentSlide = () => {
    setCurrentContentSlide((prev) => (prev - 1 + contentSlides.length) % contentSlides.length)
  }

  const copyToClipboard = () => {
    navigator.clipboard
      .writeText(lessonData.shareUrl)
      .then(() => {
        alert("URL kopyalandı!")
      })
      .catch((err) => {
        console.error("Kopyalama başarısız oldu:", err)
      })
  }

  const togglePlay = () => {
    setIsPlaying(!isPlaying)
  }

  // Simulate video progress
  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setVideoProgress((prev) => {
          if (prev >= 100) {
            setIsPlaying(false)
            clearInterval(interval)
            return 100
          }
          return prev + 1
        })
      }, 1000)
      return () => clearInterval(interval)
    }
  }, [isPlaying])

  const handleShare = () => {
    setCurrentShareUrl(lessonData.shareUrl)
    setShowShareDialog(true)
  }

  return (
    <div className="min-h-screen bg-[#f5f2f4]">
      <div className="container px-4 py-6 mx-auto md:px-6">
        <div className="mb-6 flex items-center">
          <Link href="/">
            <Button variant="ghost" size="icon" className="mr-4">
              <ArrowLeft className="h-5 w-5 text-[#470b69]" />
            </Button>
          </Link>
          <h1 className="text-xl font-medium text-center flex-1">Tamamlanan ders</h1>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <h2 className="text-xl font-bold text-[#470b69] mb-4">{lessonData.title}</h2>

          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div>
              <p className="text-gray-600 mb-1">
                {lessonData.date}, {lessonData.time}
              </p>
              <p className="text-gray-600">
                {lessonData.student} ve {lessonData.teacher}
              </p>
            </div>

            {lessonData.hasRecording && (
              <Button
                className="mt-2 md:mt-0 bg-[#470b69] hover:bg-[#470b69]/80 text-white"
                onClick={() => setShowRecordingDialog(true)}
              >
                <span className="flex items-center">
                  <span className="mr-2 h-2 w-2 rounded-full bg-red-500"></span>
                  Kayıt izle
                </span>
              </Button>
            )}
          </div>

          <div className="bg-[#f5f2f4] p-4 rounded-lg mb-6">
            <div className="flex items-center justify-between">
              <p className="font-medium text-[#470b69]">Dersi beğendin mi?</p>
              <div className="flex gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className={`${liked ? "bg-[#470b69]/10" : ""} text-[#470b69] hover:bg-[#470b69]/10`}
                  onClick={handleLike}
                >
                  <ThumbsUp className={`h-5 w-5 ${liked ? "fill-[#470b69]" : ""}`} />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className={`${disliked ? "bg-[#470b69]/10" : ""} text-[#470b69] hover:bg-[#470b69]/10`}
                  onClick={handleDislike}
                >
                  <ThumbsDown className={`h-5 w-5 ${disliked ? "fill-[#470b69]" : ""}`} />
                </Button>
              </div>
            </div>
          </div>

          {/* Slide indicators */}
          <div className="flex justify-center mb-4">
            {[...Array(10)].map((_, i) => (
              <div
                key={i}
                className={`h-2 w-2 rounded-full mx-1 ${i === currentSlide ? "bg-[#470b69]" : "bg-gray-300"}`}
                onClick={() => setCurrentSlide(i)}
              ></div>
            ))}
          </div>

          <div className="relative mb-6">
            <div
              className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/20 hover:bg-black/40 transition-colors rounded-full p-2 cursor-pointer z-10"
              onClick={prevSlide}
            >
              <ChevronLeft className="h-6 w-6 text-white" />
            </div>
            <img
              src={lessonData.imageUrl || "/placeholder.svg"}
              alt="Lesson Screenshot"
              className="w-full h-auto rounded-lg"
            />
            <div
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/20 hover:bg-black/40 transition-colors rounded-full p-2 cursor-pointer z-10"
              onClick={nextSlide}
            >
              <ChevronRight className="h-6 w-6 text-white" />
            </div>

            {/* Teacher thumbnail */}
            <div className="absolute bottom-4 right-4 w-24 h-24 rounded-lg overflow-hidden border-2 border-white">
              <img
                src="/placeholder.svg?height=96&width=96&text=Teacher"
                alt="Teacher"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Social sharing section */}
          <div className="bg-[#f5f2f4] p-4 rounded-lg mb-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="bg-[#470b69] rounded-full p-2">
                  <Share2 className="h-5 w-5 text-white" />
                </div>
                <span className="font-medium text-[#470b69]">Sosyal medyada paylaşın ve ₺600 kazanın</span>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" className="text-[#470b69] hover:bg-[#470b69]/10" onClick={handleShare}>
                  <Share2 className="h-5 w-5 mr-2" />
                  Paylaş
                </Button>
                <Button variant="ghost" className="text-[#470b69] hover:bg-[#470b69]/10" onClick={handleHeart}>
                  <Heart className={`h-5 w-5 mr-2 ${hearted ? "fill-red-500 text-red-500" : ""}`} />
                  Beğen
                </Button>
              </div>
            </div>
          </div>

          {/* Teacher feedback section */}
          <div className="bg-[#f5f2f4] p-4 rounded-lg mb-6">
            <div className="flex items-start gap-3">
              <Avatar>
                <AvatarImage src={lessonData.teacherImageUrl} alt={lessonData.teacher} />
                <AvatarFallback className="bg-[#a38fb2] text-white">AH</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <p className="text-[#470b69]">{showTurkishTranslation ? lessonData.contentTR : lessonData.content}</p>

                {!showFullText ? (
                  <button
                    onClick={() => setShowFullText(true)}
                    className="text-[#470b69] hover:text-[#a38fb2] text-sm font-medium mt-2"
                  >
                    daha fazla oku
                  </button>
                ) : (
                  <div className="mt-4">
                    <h4 className="font-medium text-[#470b69] mb-1">
                      {showTurkishTranslation ? "Başarı Alanları" : "Areas of success"}
                    </h4>
                    <p className="text-sm text-gray-600 mb-3">
                      {showTurkishTranslation ? lessonData.areasOfSuccessTR : lessonData.areasOfSuccess}
                    </p>

                    <h4 className="font-medium text-[#470b69] mb-1">
                      {showTurkishTranslation ? "Öğretmen Önerileri" : "Teacher recommendations"}
                    </h4>
                    <p className="text-sm text-gray-600 mb-3">
                      {showTurkishTranslation ? lessonData.teacherRecommendationsTR : lessonData.teacherRecommendations}
                    </p>

                    <button
                      onClick={() => setShowFullText(false)}
                      className="text-[#470b69] hover:text-[#a38fb2] text-sm font-medium mt-2"
                    >
                      daha az göster
                    </button>
                  </div>
                )}

                <button
                  className="flex items-center text-[#470b69] hover:text-[#a38fb2] text-sm font-medium mt-2"
                  onClick={() => setShowTurkishTranslation(!showTurkishTranslation)}
                >
                  <Languages className="h-4 w-4 mr-1" />
                  {showTurkishTranslation ? "ENG original" : "TUR çeviri"}
                </button>
              </div>
            </div>
          </div>

          {/* Practice section */}
          <div className="mb-6">
            <h3 className="text-lg font-bold text-[#470b69] mb-3">Eğlenceli pratiğinizin zamanı geldi!</h3>
            <p className="text-gray-600 mb-3">
              Yapılan alıştırmalar: {lessonData.completedExercises} / {lessonData.totalExercises}
            </p>
            <Button
              className="bg-[#39ff14] hover:bg-[#39ff14]/80 text-[#470b69] font-medium"
              onClick={() => router.push("/student/asya")}
            >
              Pratik yap
            </Button>
          </div>

          {/* Isınma Alıştırmaları - Video Player */}
          <div className="mt-6 mb-6">
            <h3 className="text-lg font-bold text-[#470b69] mb-3">Isınma Alıştırmaları</h3>
            <div className="bg-[#f9f3e5] p-4 rounded-lg">
              <div className="flex flex-col items-center">
                <div className="w-full max-w-md relative rounded-lg overflow-hidden">
                  <img
                    src="/placeholder.svg?height=300&width=600&text=Novakid+Tales"
                    alt="Novakid Tales"
                    className="w-full h-auto"
                  />

                  {/* Video controls overlay */}
                  <div className="absolute bottom-0 left-0 right-0 bg-black/50 p-2">
                    <div className="flex items-center justify-between text-white mb-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-white hover:bg-white/20 p-1"
                        onClick={togglePlay}
                      >
                        {isPlaying ? (
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="lucide lucide-pause"
                          >
                            <rect width="4" height="16" x="6" y="4" />
                            <rect width="4" height="16" x="14" y="4" />
                          </svg>
                        ) : (
                          <Play className="h-6 w-6" />
                        )}
                      </Button>

                      <div className="flex-1 mx-2">
                        <div className="h-1 bg-white/30 rounded-full" ref={videoProgressRef}>
                          <div className="h-full bg-white rounded-full" style={{ width: `${videoProgress}%` }}></div>
                        </div>
                      </div>

                      <span className="text-xs mr-2">{videoTime}</span>

                      <div className="flex items-center">
                        <Button variant="ghost" size="icon" className="text-white hover:bg-white/20 p-1">
                          <Volume2 className="h-5 w-5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-white hover:bg-white/20 p-1">
                          <Subtitles className="h-5 w-5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-white hover:bg-white/20 p-1">
                          <Settings className="h-5 w-5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-white hover:bg-white/20 p-1">
                          <Maximize2 className="h-5 w-5" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Time indicator */}
                  <div className="absolute bottom-16 left-3 bg-white text-black text-xs px-2 py-1 rounded">01:42</div>

                  {/* Play button overlay (when paused) */}
                  {!isPlaying && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="bg-black/50 rounded-full p-4 cursor-pointer" onClick={togglePlay}>
                        <Play className="h-10 w-10 text-white" />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* İçerik - Content Slider */}
          <div className="mt-6">
            <h3 className="text-lg font-bold text-[#470b69] mb-3">İçerik</h3>
            <div className="relative rounded-lg overflow-hidden">
              <div
                className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/20 hover:bg-black/40 transition-colors rounded-full p-2 cursor-pointer z-10"
                onClick={prevContentSlide}
              >
                <ChevronLeft className="h-6 w-6 text-black" />
              </div>

              <div className="bg-[#f9f3e5] p-4 rounded-lg">
                <div className="flex flex-col items-center text-center">
                  <div className="w-full max-w-md relative">
                    <img
                      src="/placeholder.svg?height=300&width=600&text=NOVAKID"
                      alt="Content Slide"
                      className="w-full h-auto"
                    />
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div className="bg-white rounded-full px-6 py-2 mb-4">
                        <span className="text-[#470b69] font-bold text-xl">EDDYKIDS</span>
                      </div>
                      <h3 className="text-[#4a9d9b] text-4xl font-bold mb-2">Book 2</h3>
                      <h4 className="text-[#b75a8c] text-3xl font-bold mb-2">
                        {contentSlides[currentContentSlide].title}
                      </h4>
                      <h5 className="text-[#b75a8c] text-2xl font-bold mb-4">
                        {contentSlides[currentContentSlide].subtitle}
                      </h5>
                      <p className="text-black text-xl">{contentSlides[currentContentSlide].description}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/20 hover:bg-black/40 transition-colors rounded-full p-2 cursor-pointer z-10"
                onClick={nextContentSlide}
              >
                <ChevronRight className="h-6 w-6 text-black" />
              </div>
            </div>

            {/* Content slide indicators */}
            <div className="flex justify-center mt-4">
              {contentSlides.map((_, i) => (
                <div
                  key={i}
                  className={`h-2 w-2 rounded-full mx-1 ${i === currentContentSlide ? "bg-[#470b69]" : "bg-gray-300"}`}
                  onClick={() => setCurrentContentSlide(i)}
                ></div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Remove the entire "Son Aktiviteler" section */}

      {/* Recording Dialog */}
      <Dialog open={showRecordingDialog} onOpenChange={() => setShowRecordingDialog(false)} />

      {/* Share Dialog */}
      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">Paylaş</DialogTitle>
          </DialogHeader>
          <div className="flex justify-center space-x-2 py-4">
            <button className="bg-[#3b5998] text-white p-3 rounded-full">
              <Facebook className="h-6 w-6" />
            </button>
            <button className="bg-[#1DA1F2] text-white p-3 rounded-full">
              <Twitter className="h-6 w-6" />
            </button>
            <button className="bg-[#0088cc] text-white p-3 rounded-full">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-send"
              >
                <path d="m22 2-7 20-4-9-9-4Z" />
                <path d="M22 2 11 13" />
              </svg>
            </button>
            <button className="bg-[#25D366] text-white p-3 rounded-full">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-message-circle"
              >
                <path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z" />
              </svg>
            </button>
            <button className="bg-[#0077B5] text-white p-3 rounded-full">
              <Linkedin className="h-6 w-6" />
            </button>
          </div>
          <div className="flex items-center space-x-2">
            <div className="grid flex-1 gap-2">
              <Input className="border-gray-300" value={currentShareUrl} readOnly />
            </div>
            <Button type="submit" size="sm" className="px-3" onClick={copyToClipboard}>
              <span>kopyala</span>
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
