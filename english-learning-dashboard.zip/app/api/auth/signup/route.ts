import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()

    // In a real application, you would validate the data and save it to a database
    // For this example, we'll simulate a successful signup

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Check if email already exists (simulated)
    if (body.email === "test@example.com") {
      return NextResponse.json({ message: "Bu e-posta adresi zaten kullanılıyor." }, { status: 400 })
    }

    // Return success response
    return NextResponse.json(
      {
        message: "Kayıt başarılı",
        user: {
          id: "user_" + Math.random().toString(36).substring(2, 9),
          name: body.fullName,
          email: body.email,
        },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Signup error:", error)
    return NextResponse.json({ message: "Sunucu hatası" }, { status: 500 })
  }
}
