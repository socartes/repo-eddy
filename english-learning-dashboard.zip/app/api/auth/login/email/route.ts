import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()

    // In a real application, you would validate the email and send a login link or OTP
    // For this example, we'll simulate a successful login

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // E-posta kontrolünü daha belirgin hale getirelim
    // Check if email exists (simulated)
    if (body.email === "nonexistent@example.com") {
      return NextResponse.json({ message: "Bu e-posta adresi ile kayıtlı bir hesap bulunamadı." }, { status: 404 })
    }

    // Kayıtlı olmayan e-postalar için genel kontrol ekleyelim
    // Gerçek uygulamada bu kontrol veritabanı sorgusu ile yapılır
    const registeredEmails = ["test@example.com", "user@example.com", "admin@example.com"]
    if (!registeredEmails.includes(body.email)) {
      return NextResponse.json({ message: "Bu e-posta adresi sistemde kayıtlı değil." }, { status: 404 })
    }

    // Return success response
    return NextResponse.json(
      {
        message: "Giriş başarılı",
        user: {
          id: "user_" + Math.random().toString(36).substring(2, 9),
          email: body.email,
        },
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ message: "Sunucu hatası" }, { status: 500 })
  }
}
