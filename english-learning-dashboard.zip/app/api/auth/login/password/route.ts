import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()
    const { email, phone, password } = body

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Kullanıcı bilgilerini güncelleyelim ve admin@example.com'u ekleyelim
    const validUsers = [
      { email: "test@example.com", phone: "5551234567", password: "123456" },
      { email: "user@example.com", phone: "5559876543", password: "password" },
      { email: "admin@example.com", phone: "5551112233", password: "admin123" },
    ]

    // Kullanıcı adı ve şifre kontrolü
    const user = validUsers.find((user) => (email && user.email === email) || (phone && user.phone === phone))

    // Kullanıcı bulunamadıysa
    if (!user) {
      return NextResponse.json(
        {
          success: false,
          message: email ? "Bu e-posta adresi sistemde kayıtlı değil." : "Bu telefon numarası sistemde kayıtlı değil.",
        },
        { status: 404 },
      )
    }

    // Şifre kontrolü
    if (user.password !== password) {
      return NextResponse.json(
        {
          success: false,
          message: "Şifre hatalı. Lütfen tekrar deneyin.",
        },
        { status: 401 },
      )
    }

    // Başarılı giriş
    return NextResponse.json(
      {
        success: true,
        message: "Giriş başarılı",
        user: {
          id: "user_" + Math.random().toString(36).substring(2, 9),
          email: user.email,
          phone: user.phone,
        },
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ success: false, message: "Sunucu hatası" }, { status: 500 })
  }
}
