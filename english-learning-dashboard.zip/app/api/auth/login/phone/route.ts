import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()

    // In a real application, you would validate the phone number and send an OTP
    // For this example, we'll simulate a successful login

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Telefon numarası kontrolünü daha belirgin hale getirelim
    // Check if phone exists (simulated)
    if (body.phone === "+901234567890") {
      return NextResponse.json({ message: "Bu telefon numarası ile kayıtlı bir hesap bulunamadı." }, { status: 404 })
    }

    // Kayıtlı olmayan telefon numaraları için genel kontrol ekleyelim
    // Gerçek uygulamada bu kontrol veritabanı sorgusu ile yapılır
    const registeredPhones = ["+905551234567", "+905559876543", "+905551112233"]
    if (!registeredPhones.includes(body.phone)) {
      return NextResponse.json({ message: "Bu telefon numarası sistemde kayıtlı değil." }, { status: 404 })
    }

    // Return success response
    return NextResponse.json(
      {
        message: "Giriş başarılı",
        user: {
          id: "user_" + Math.random().toString(36).substring(2, 9),
          phone: body.phone,
        },
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ message: "Sunucu hatası" }, { status: 500 })
  }
}
