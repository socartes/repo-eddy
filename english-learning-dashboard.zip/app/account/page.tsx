"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, HelpCircle, Lock, Wifi, Headphones, Volume2, FileText, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export default function AccountPage() {
  const [language, setLanguage] = useState("TUR")
  const [timezone, setTimezone] = useState("Europe/Istanbul")
  const [backupTeacher, setBackupTeacher] = useState("Evet")
  const [promoCode, setPromoCode] = useState("")

  // Örnek veri
  const children = [
    { name: "Asya", age: 8 },
    { name: "Ertuğ", age: 15 },
    { name: "enes", age: 11 },
  ]

  const transactions = [
    {
      id: 1,
      date: "8.04.2025 14:35",
      description: "Deneme dersi",
      amount: "1 Deneme dersi",
    },
    {
      id: 2,
      date: "2.04.2025 19:09",
      description: "02/04/2025 18:30 +03 tarihindeki ders ücreti, öğrenci: Asya",
      amount: "-1 Standard ders",
    },
    {
      id: 3,
      date: "26.03.2025 19:09",
      description: "26/03/2025 18:30 +03 tarihindeki ders ücreti, öğrenci: Asya",
      amount: "-1 Standard ders",
    },
    {
      id: 4,
      date: "19.03.2025 19:10",
      description: "19/03/2025 18:30 +03 tarihindeki ders ücreti, öğrenci: Asya",
      amount: "-1 Standard ders",
    },
    {
      id: 5,
      date: "13.03.2025 23:31",
      description: "Haftada 1 Standard derslik, 4 haftalık otomatik ödemeli üyelik, (promosyon kodu indirimi)",
      amount: "2.4 ders",
    },
  ]

  const promotions = [
    {
      code: "WINTER_CHALLENGE_2024_2125912",
      activationDate: "3.02.2025 12:31",
      expiryDate: "12.06.2025 23:30",
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center">
          <Link href="/" className="flex items-center text-[#470b69]">
            <ArrowLeft className="mr-2 h-5 w-5" />
            <span>Ana Sayfaya Dön</span>
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Fatma Hacıoğlu</h1>

        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <section className="mb-8">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Bağlantılarınız</h2>
              <div className="space-y-2">
                <p className="text-[#470b69]">ftmhacioglu@gmail.com</p>
                <p className="text-[#470b69]">+905054513823</p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Dil:</h2>
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-[180px] text-[#470b69]">
                  <SelectValue placeholder="Dil seçin" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="TUR">TUR</SelectItem>
                  <SelectItem value="ENG">ENG</SelectItem>
                  <SelectItem value="DEU">DEU</SelectItem>
                </SelectContent>
              </Select>
            </section>

            <section className="mb-8">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Saat dilimi:</h2>
              <Select value={timezone} onValueChange={setTimezone}>
                <SelectTrigger className="w-[180px] text-[#470b69]">
                  <SelectValue placeholder="Saat dilimi seçin" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Europe/Istanbul">Europe/Istanbul</SelectItem>
                  <SelectItem value="Europe/London">Europe/London</SelectItem>
                  <SelectItem value="Europe/Paris">Europe/Paris</SelectItem>
                </SelectContent>
              </Select>
            </section>

            <section className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <h2 className="text-lg font-medium text-gray-900">Yedek öğretmenler</h2>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger>
                      <HelpCircle className="h-4 w-4 text-gray-400" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="max-w-xs">
                        Yedek öğretmen seçeneği, normal öğretmeniniz müsait olmadığında başka bir öğretmenle ders yapma
                        imkanı sağlar.
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <RadioGroup value={backupTeacher} onValueChange={setBackupTeacher} className="flex gap-4">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="Evet" id="backup-yes" />
                  <Label htmlFor="backup-yes">Evet</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="Hayır" id="backup-no" />
                  <Label htmlFor="backup-no">Hayır</Label>
                </div>
              </RadioGroup>
            </section>

            <section className="space-y-4">
              <div className="flex items-center gap-2 text-[#470b69] hover:underline">
                <Lock className="h-4 w-4" />
                <Link href="#">Şifre değiştir</Link>
              </div>
              <div className="flex items-center gap-2 text-[#470b69] hover:underline">
                <Wifi className="h-4 w-4" />
                <Link href="#">İnternet hız testi</Link>
              </div>
              <div className="flex items-center gap-2 text-[#470b69] hover:underline">
                <HelpCircle className="h-4 w-4" />
                <Link href="#">Teknik öneri</Link>
              </div>
              <div className="flex items-center gap-2 text-[#470b69] hover:underline">
                <Volume2 className="h-4 w-4" />
                <Link href="#">Ses/video testi</Link>
              </div>
              <div className="flex items-center gap-2 text-[#470b69] hover:underline">
                <Headphones className="h-4 w-4" />
                <Link href="#">Alıştırma çizimi</Link>
              </div>
              <div className="flex items-center gap-2 text-[#470b69] hover:underline">
                <FileText className="h-4 w-4" />
                <Link href="#">Gizlilik Politikası</Link>
              </div>
              <div className="flex items-center gap-2 text-[#470b69] hover:underline">
                <ExternalLink className="h-4 w-4" />
                <Link href="#">Şartlar ve koşullar</Link>
              </div>
            </section>
          </div>

          <div>
            <section className="mb-8 bg-gray-50 p-6 rounded-lg">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Kaydedilmiş çocuklar:</h2>
              <div className="flex flex-wrap gap-2">
                {children.map((child) => (
                  <div
                    key={child.name}
                    className="bg-white border border-[#470b69]/30 rounded-full px-4 py-2 text-[#470b69]"
                  >
                    {child.name} {child.age} yaş
                  </div>
                ))}
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Promosyon kodları</h2>
              <div className="flex gap-2 mb-6">
                <Input
                  placeholder="Promosyon kodu"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                  className="max-w-xs"
                />
                <Button variant="secondary" className="bg-gray-200 hover:bg-gray-300 text-gray-800">
                  Uygula
                </Button>
              </div>

              {promotions.length > 0 && (
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b">
                        <th className="py-2 px-4 text-left font-medium text-gray-500">Promosyon kodu</th>
                        <th className="py-2 px-4 text-left font-medium text-gray-500">Etkinleştirme tarihi</th>
                        <th className="py-2 px-4 text-left font-medium text-gray-500">Son kullanma tarihi</th>
                      </tr>
                    </thead>
                    <tbody>
                      {promotions.map((promo) => (
                        <tr key={promo.code} className="border-b">
                          <td className="py-3 px-4">
                            <div className="flex items-center">
                              <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center mr-2">
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="12"
                                  height="12"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  className="text-green-600"
                                >
                                  <polyline points="20 6 9 17 4 12" />
                                </svg>
                              </div>
                              {promo.code}
                            </div>
                          </td>
                          <td className="py-3 px-4">{promo.activationDate}</td>
                          <td className="py-3 px-4">{promo.expiryDate}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>

            <section>
              <h2 className="text-lg font-medium text-gray-900 mb-4">Bakiye geçmişi</h2>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="py-2 px-4 text-left font-medium text-gray-500">Tarih</th>
                      <th className="py-2 px-4 text-left font-medium text-gray-500">Açıklama</th>
                      <th className="py-2 px-4 text-right font-medium text-gray-500">Miktar</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((transaction) => (
                      <tr key={transaction.id} className="border-b">
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center mr-2">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="12"
                                height="12"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="text-green-600"
                              >
                                <polyline points="20 6 9 17 4 12" />
                              </svg>
                            </div>
                            {transaction.date}
                          </div>
                        </td>
                        <td className="py-3 px-4">{transaction.description}</td>
                        <td className="py-3 px-4 text-right">{transaction.amount}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        </div>
      </main>
    </div>
  )
}
