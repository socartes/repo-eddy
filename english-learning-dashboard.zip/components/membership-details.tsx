"use client"
import { ArrowLeft, CreditCard, HelpCircle, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface MembershipDetailsProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function MembershipDetails({ open, onOpenChange }: MembershipDetailsProps) {
  // This would normally come from an API or database
  const membershipData = {
    price: "₺2.164",
    teacherCategory: "Standart",
    membershipDuration: "4 hafta",
    totalDuration: "24 hafta",
    remainingLessons: "1/4",
    weeklyLessonCount: "1",
    membershipStartDate: "5 Haz, 2025",
    nextPaymentDate: "10 Nis, 2025",
    paymentAmount: "₺2.164",
    cardType: "Mastercard",
    cardNumber: "•••• 0026",
    cardExpiry: "4/27",
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto p-4">
        <DialogHeader className="flex flex-row items-center justify-between p-0 mb-3">
          <div className="flex items-center">
            <Button variant="ghost" size="icon" className="h-8 w-8 mr-1" onClick={() => onOpenChange(false)}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <DialogTitle className="text-base">Üyelik</DialogTitle>
          </div>
        </DialogHeader>

        {/* Help Alert */}
        <Alert className="bg-gray-50 border-gray-200 mb-3 py-2">
          <HelpCircle className="h-4 w-4 text-[#470b69]" />
          <AlertDescription className="flex flex-col text-xs">
            <span className="font-medium text-[#470b69]">Yardıma mı ihtiyacınız var?</span>
            <span className="text-gray-600">
              <a href="#" className="text-[#470b69] hover:underline">
                Yardım merkezimizde
              </a>{" "}
              üyeliğinizi nasıl yöneteceğinize ilişkin ipuçlarımızı göz atın.
            </span>
          </AlertDescription>
        </Alert>

        {/* Active Membership */}
        <div className="border rounded-lg p-3 mb-3">
          <div className="flex justify-between items-center mb-3">
            <div className="flex items-center">
              <Star className="h-4 w-4 text-yellow-500 mr-1.5 fill-yellow-500" />
              <span className="font-medium">Aktif üyelik</span>
            </div>
            <span className="font-bold">{membershipData.price}</span>
          </div>

          <div className="space-y-1.5 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Öğretmen kategorisi</span>
              <span className="font-medium">{membershipData.teacherCategory}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Üyelik süresi</span>
              <span className="font-medium">{membershipData.membershipDuration}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Tüm süre</span>
              <span className="font-medium">{membershipData.totalDuration}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Kalan dersler</span>
              <span className="font-medium">{membershipData.remainingLessons}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Haftalık ders sayısı</span>
              <span className="font-medium">{membershipData.weeklyLessonCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Üyelik bitiş tarihi</span>
              <span className="font-medium">{membershipData.membershipStartDate}</span>
            </div>
          </div>

          <div className="mt-4 space-y-2">
            <Button className="w-full bg-[#6c47ff] hover:bg-[#6c47ff]/80 text-sm h-9">Düzenle veya yenile</Button>
            <Button
              variant="outline"
              className="w-full border-[#470b69] text-[#470b69] hover:bg-[#470b69] hover:text-white text-sm h-9"
            >
              Dondur
            </Button>
            <div className="text-center">
              <a href="#" className="text-red-500 text-xs hover:underline">
                Otomatik ödemeyi iptal et
              </a>
            </div>
          </div>
        </div>

        {/* Payment Method */}
        <div className="border rounded-lg p-3">
          <div className="flex items-center mb-3">
            <CreditCard className="h-4 w-4 text-red-500 mr-1.5" />
            <span className="font-medium">Ödeme yöntemi</span>
          </div>

          <div className="space-y-1.5 mb-3 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Gelecek ödeme tarihi</span>
              <span className="font-medium">{membershipData.nextPaymentDate}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Ödeme tutarı</span>
              <span className="font-medium">{membershipData.paymentAmount}</span>
            </div>
          </div>

          <div className="border rounded-lg p-2 bg-gray-50 mb-3">
            <div className="flex items-center">
              <div className="w-8 h-5 bg-gradient-to-r from-red-500 to-yellow-500 rounded mr-2"></div>
              <div>
                <div className="font-medium text-sm">
                  {membershipData.cardType} {membershipData.cardNumber}
                </div>
                <div className="text-xs text-gray-500">{membershipData.cardExpiry}</div>
              </div>
            </div>
          </div>

          <Button variant="outline" className="w-full text-sm h-9">
            Kartı değiştir
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
