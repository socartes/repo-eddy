"use client"

import { Plus } from "lucide-react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface ReferralProgramProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function ReferralProgram({ open, onOpenChange }: ReferralProgramProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto p-0">
        <div className="p-6">
          <div className="flex justify-between items-center border-b pb-4 mb-6">
            <div className="flex items-center gap-4">
              <svg width="32" height="32" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M60 10C32.4 10 10 32.4 10 60C10 87.6 32.4 110 60 110C87.6 110 110 87.6 110 60C110 32.4 87.6 10 60 10Z"
                  fill="white"
                />
                <path
                  d="M60 30C50 30 42 38 42 48V72C42 82 50 90 60 90C70 90 78 82 78 72V48C78 38 70 30 60 30Z"
                  fill="#470B69"
                />
              </svg>
              <div className="flex space-x-6">
                {["Ana Sayfa", "Ders İşlemleri", "Kütüphane", "Kazanımlar", "Konuşma pratiği"].map((item) => (
                  <span key={item} className="text-gray-600 font-medium">
                    {item}
                  </span>
                ))}
                <span className="text-[#470b69] font-medium relative after:absolute after:bottom-0 after:left-0 after:w-full after:h-[2px] after:bg-[#470b69]">
                  Bonusu kapın
                  <span className="ml-1 text-xs bg-red-500 text-white px-1 rounded">New</span>
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                <Plus className="h-5 w-5 text-gray-600" />
              </button>
              <div className="flex -space-x-2">
                <Avatar className="border-2 border-white">
                  <AvatarImage src="/placeholder.svg?height=32&width=32&text=1" />
                  <AvatarFallback>1</AvatarFallback>
                </Avatar>
                <Avatar className="border-2 border-white">
                  <AvatarImage src="/placeholder.svg?height=32&width=32&text=2" />
                  <AvatarFallback>2</AvatarFallback>
                </Avatar>
                <Avatar className="border-2 border-white">
                  <AvatarImage src="/placeholder.svg?height=32&width=32&text=3" />
                  <AvatarFallback>3</AvatarFallback>
                </Avatar>
              </div>
              <Avatar className="border-2 border-white">
                <AvatarImage src="/placeholder.svg?height=32&width=32&text=FH" />
                <AvatarFallback>FH</AvatarFallback>
              </Avatar>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Arkadaşlarınızı Novakid'e davet edin!</h2>

              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-[#470b69] font-bold">
                    1
                  </div>
                  <div>
                    <p className="font-medium mb-2">Referans bağlantınızı bir arkadaşınızla paylaşın.</p>
                    <div className="text-sm text-gray-600 mb-3">Bağlantı aracılığıyla bir arkadaşınızı davet edin</div>
                    <div className="flex">
                      <Input
                        value="https://www.novakid.com.tr/r/hc7qa?utm_r"
                        readOnly
                        className="rounded-r-none border-r-0"
                      />
                      <Button className="rounded-l-none bg-[#470b69]">kopyala</Button>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-[#470b69] font-bold">
                    2
                  </div>
                  <div>
                    <p className="font-medium mb-2">
                      Arkadaşınız bağlantı aracılığıyla kaydolur ve bir bonus kazanır: deneme dersini tamamladıktan
                      sonra hesabına ₺600 eklenir.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-[#470b69] font-bold">
                    3
                  </div>
                  <div>
                    <p className="font-medium mb-2">
                      Arkadaşınız deneme dersini başarıyla tamamladığında ₺300 ve ilk alımını yaptığında ₺300 bonus
                      hesabınıza eklenir. Sonrasında satın aldıkları her üyelik tutarının % 5 kadarı bonus kazanmaya
                      devam edersiniz!
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#f5f2f4] p-6 rounded-lg">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-10 h-10 bg-[#470b69] rounded-full flex items-center justify-center text-white">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-user"
                  >
                    <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
                    <circle cx="12" cy="7" r="4" />
                  </svg>
                </div>
                <h2 className="text-xl font-bold text-[#470b69]">
                  ARKADAŞLARINIZI NOVAKİD'E DAVET EDİN VE AVANTAJLARIN TADINI ÇIKARIN!
                </h2>
              </div>

              <div className="space-y-4">
                <div className="flex items-start gap-2">
                  <div className="text-yellow-500 text-xl">★</div>
                  <p>
                    Üyelik satın alırken tutarın <span className="font-bold">% 25 oranına kadar</span> tasarruf etmek
                    için bonusları kullanın
                  </p>
                </div>
                <div className="flex items-start gap-2">
                  <div className="text-yellow-500 text-xl">★</div>
                  <p>
                    İstediğiniz kadar arkadaşınıza referans olabilirsiniz. Kazanabileceğiniz bonuslarla ilgili herhangi
                    bir sınır yok!
                  </p>
                </div>
              </div>

              <div className="mt-8 p-4 bg-white rounded-lg">
                <p className="text-center text-gray-600">Henüz herhangi bir bonus işleminiz bulunmamaktadır.</p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
