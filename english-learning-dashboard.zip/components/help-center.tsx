"use client"

import { Search, ChevronDown } from "lucide-react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"

interface HelpCenterProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function HelpCenter({ open, onOpenChange }: HelpCenterProps) {
  const helpCategories = [
    {
      icon: "✏️",
      title: "Ders programınızı düzenleyin",
      description: "Planlama, taşıma ve iptal seçenekleri de dahil olmak üzere ders programını yönetme.",
      author: "Astro",
      articles: 6,
    },
    {
      icon: "💬",
      title: "Üyelikler, Ödemeler ve Bonuslar",
      description: "Abonelik türleri, ödemeler, hesap ve bonus bakiyesi",
      author: "Astro",
      articles: 17,
    },
    {
      icon: "📚",
      title: "Derse nasıl hazırlanır?",
      description: "Teknik öneriler, bağlantı sorunlarını çözme ve diğer ders gereksinimleri",
      author: "Astro",
      articles: 3,
    },
    {
      icon: "🏆",
      title: "Metodoloji",
      description: "Novakid programı, seviyeler, ilerleme ve ödevler hakkında",
      author: "Astro",
      articles: 2,
    },
    {
      icon: "👩‍🏫",
      title: "Öğretmenler",
      description: "Yedek öğretmen seçeneği de dahil olmak üzere Novakid öğretmen tercihlerinizi yönetme.",
      author: "Astro",
      articles: 2,
    },
    {
      icon: "🚀",
      title: "Novakid hesabınız",
      description: "Hesabınıza yönelik rehberlik, ayarlar ve kişisel bilgilerin yönetilmesi",
      author: "Astro",
      articles: 4,
    },
    {
      icon: "🌍",
      title: "World Kids Academy (Uluslar arası gruplarda konuşma dersleri)",
      description:
        "Konuşma Grup Derslerini Keşfedin; Bu derslere kimlerin katılabileceği, nasıl rezervasyon yaptırılacağı ve...",
      author: "Astro",
      articles: 7,
    },
    {
      icon: "⚡",
      title: "Kış Yarışması",
      description: "",
      author: "Astro ve 1 diğer",
      articles: 2,
    },
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto p-0">
        <div className="bg-[#9333ea] text-white p-6">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <svg width="32" height="32" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M60 10C32.4 10 10 32.4 10 60C10 87.6 32.4 110 60 110C87.6 110 110 87.6 110 60C110 32.4 87.6 10 60 10Z"
                  fill="white"
                />
                <path
                  d="M60 30C50 30 42 38 42 48V72C42 82 50 90 60 90C70 90 78 82 78 72V48C78 38 70 30 60 30Z"
                  fill="#470B69"
                />
              </svg>
              <span className="text-xl font-bold">EDDY</span>
            </div>
            <div className="flex items-center gap-2">
              <span>Türkçe</span>
              <ChevronDown className="h-4 w-4" />
            </div>
          </div>
          <h1 className="text-2xl font-bold mb-6">Novakid Ekibinden tavsiyeler ve yanıtlar</h1>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Makale ara..."
              className="pl-10 bg-white/20 border-none text-white placeholder:text-white/70 rounded-lg"
            />
          </div>
        </div>

        <div className="p-6">
          <div className="grid gap-4">
            {helpCategories.map((category, index) => (
              <div
                key={index}
                className="border rounded-lg p-4 flex items-start gap-4 hover:shadow-md transition-shadow"
              >
                <div className="w-12 h-12 bg-[#f5f2f4] rounded-lg flex items-center justify-center text-2xl">
                  {category.icon}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-[#470b69] mb-1">{category.title}</h3>
                  <p className="text-sm text-gray-600 mb-2">{category.description}</p>
                  <div className="flex items-center text-xs text-gray-500">
                    <span>Yazar: {category.author}</span>
                    <span className="mx-2">•</span>
                    <span>{category.articles} makale</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
