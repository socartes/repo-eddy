"use client"

import { useState } from "react"
import {
  Calendar,
  Clock,
  LogOut,
  MessageCircle,
  MoreVertical,
  Plus,
  User,
  Video,
  HelpCircle,
  CreditCard,
  Heart,
  Share2,
  Star,
  Target,
  Facebook,
  Twitter,
  Linkedin,
  Trash2,
  MoveRight,
  LogIn,
  Gift,
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import Image from "next/image"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import MembershipDetails from "./membership-details"

export default function Dashboard() {
  // Dashboard bileşeninin başında yeni state'leri ekleyelim
  const [activeStudent, setActiveStudent] = useState("Asya")
  const [activePage, setActivePage] = useState("Ana Sayfa")
  const [showMembershipDetails, setShowMembershipDetails] = useState(false)
  const [likedActivities, setLikedActivities] = useState<Record<number, boolean>>({})
  const [showShareDialog, setShowShareDialog] = useState(false)
  const [currentShareUrl, setCurrentShareUrl] = useState("")
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [showAddStudentModal, setShowAddStudentModal] = useState(false)
  const [newStudentName, setNewStudentName] = useState("")
  const [newStudentBirthdate, setNewStudentBirthdate] = useState("")
  const [newStudentGender, setNewStudentGender] = useState<"Kız" | "Erkek">("Kız")
  const [students, setStudents] = useState(["Asya", "Ertuğ"])
  const [showHelpCenter, setShowHelpCenter] = useState(false)
  const [showReferralProgram, setShowReferralProgram] = useState(false)
  const router = useRouter()

  // Recent activities data
  const recentActivities = [
    {
      id: 1,
      teacher: "April H",
      student: "Asya",
      timeAgo: "6 gün önce",
      title: "Magic Academy Quest 3: Astro, the balloon - Animals Letter sounds ur/or/ure",
      content: "Hello, Asya! It was lovely to see you in class today. Thank you for all of your hard work. Keep it up!",
      areasOfSuccess:
        "You managed to practice the use of can/can't with action verbs, learn the vocabulary words for sports (football, volleyball, badminton, basketball), learn the vocabulary words for animals (tiger, zebra, giraffe, crocodile, rhino, monkey, elephant, snake), talk about your favourites using 'My favourite ... is ... .' and 'I like ... ', play out the dialogues with the teacher",
      teacherRecommendations:
        "Please continue to practice on recognizing and saying the letters 'ur', 'or', and 'ure', and read words with them, blending words using the letters 'ur', 'or' and 'ure'. Well done for today!",
      likes: 0,
      imageUrl: "/placeholder.svg?height=300&width=600&text=Lesson+Screenshot",
      teacherImageUrl: "/placeholder.svg?height=48&width=48&text=AH",
      studentImageUrl: "/placeholder.svg?height=48&width=48&text=A",
      shareUrl: "https://www.novakid.com.tr/card?id=vRUM9FO1TvishEd7",
    },
    {
      id: 2,
      teacher: "Sarah K",
      student: "Ertuğ",
      timeAgo: "8 gün önce",
      title: "Space Adventure 2: Planets and Stars - Vocabulary Building",
      content: "Hello, Ertuğ! Great job in our lesson today. You're making excellent progress!",
      areasOfSuccess:
        "You did a fantastic job learning the names of planets and space objects. Your pronunciation is improving and you remembered all the new vocabulary words from our last lesson.",
      teacherRecommendations:
        "Let's continue practicing the past tense verbs and reading short stories about space. Try to use the new vocabulary in sentences at home.",
      likes: 2,
      imageUrl: "/placeholder.svg?height=300&width=600&text=Space+Adventure",
      teacherImageUrl: "/placeholder.svg?height=48&width=48&text=SK",
      studentImageUrl: "/placeholder.svg?height=48&width=48&text=E",
      shareUrl: "https://www.novakid.com.tr/card?id=xYZ123AbCdEfGh",
    },
  ]

  const handleLike = (activityId: number) => {
    setLikedActivities((prev) => ({
      ...prev,
      [activityId]: !prev[activityId],
    }))
  }

  const handleShare = (shareUrl: string) => {
    setCurrentShareUrl(shareUrl)
    setShowShareDialog(true)
  }

  const copyToClipboard = () => {
    navigator.clipboard
      .writeText(currentShareUrl)
      .then(() => {
        alert("URL kopyalandı!")
      })
      .catch((err) => {
        console.error("Kopyalama başarısız oldu:", err)
      })
  }

  // Öğrenci ekleme fonksiyonunu ekleyelim
  const handleAddStudent = () => {
    if (newStudentName.trim()) {
      setStudents([...students, newStudentName.trim()])
      setNewStudentName("")
      setNewStudentBirthdate("")
      setShowAddStudentModal(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#f5f2f4]">
      {/* Navigation Bar */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center justify-between h-16 px-4 mx-auto md:px-6">
          {/* Logo bölümünü değiştir */}
          <div className="flex items-center gap-2">
            <Image src="/images/yeni-logo.png" alt="Eddy Logo" width={120} height={40} priority />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-4 lg:space-x-6">
            {["Ana Sayfa", "Ders İşlemleri", "Kütüphane", "Kazanımlar", "Konuşma Pratiği"].map((page) => (
              <Link
                key={page}
                href="#"
                className={`text-[#470b69] font-medium hover:text-[#a38fb2] transition-colors relative py-1 ${
                  activePage === page
                    ? "after:absolute after:bottom-0 after:left-0 after:w-full after:h-[2px] after:bg-[#470b69]"
                    : ""
                }`}
                onClick={() => setActivePage(page)}
              >
                {page}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2 md:gap-4">
            <Button
              variant="outline"
              className="hidden md:flex border-[#470b69] text-[#470b69] hover:bg-[#470b69] hover:text-white text-sm whitespace-nowrap"
              onClick={() => router.push("/bonuses")}
            >
              Bonusu Kapın
            </Button>

            {/* Student Avatars */}
            <div className="hidden md:flex -space-x-2 mr-1">
              <Avatar className="border-2 border-white cursor-pointer" onClick={() => router.push("/student/asya")}>
                <AvatarImage src="/placeholder.svg?height=32&width=32&text=A" alt="Asya" />
                <AvatarFallback className="bg-[#a38fb2] text-white">A</AvatarFallback>
              </Avatar>
              <Avatar className="border-2 border-white cursor-pointer" onClick={() => router.push("/student/ertug")}>
                <AvatarImage src="/placeholder.svg?height=32&width=32&text=E" alt="Ertuğ" />
                <AvatarFallback className="bg-[#a38fb2] text-white">E</AvatarFallback>
              </Avatar>
            </div>

            {/* User Profile Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Avatar className="cursor-pointer">
                  <AvatarImage src="/placeholder.svg?height=40&width=40&text=FH" alt="User" />
                  <AvatarFallback className="bg-[#a38fb2] text-white">FH</AvatarFallback>
                </Avatar>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-base font-medium">Fatma Hacıoğlu</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem className="py-2 cursor-pointer" onClick={() => router.push("/student/ertug")}>
                    <Avatar className="mr-2 h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32&text=E" alt="Ertuğ" />
                      <AvatarFallback className="bg-[#a38fb2] text-white">E</AvatarFallback>
                    </Avatar>
                    <span className="text-gray-600">Ertuğ</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="py-2 cursor-pointer" onClick={() => router.push("/student/asya")}>
                    <Avatar className="mr-2 h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32&text=A" alt="Asya" />
                      <AvatarFallback className="bg-[#a38fb2] text-white">A</AvatarFallback>
                    </Avatar>
                    <span className="text-gray-600">Asya</span>
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem className="py-2" onClick={() => setShowAddStudentModal(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    <span>Öğrenci ekle</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="py-2" onClick={() => router.push("/account")}>
                    <User className="mr-2 h-4 w-4" />
                    <span>Hesap</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="py-2" onClick={() => setShowMembershipDetails(true)}>
                    <CreditCard className="mr-2 h-4 w-4" />
                    <span>Üyelik</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="py-2" onClick={() => router.push("/bonuses")}>
                    <Gift className="mr-2 h-4 w-4" />
                    <span>Bonuslar</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="py-2" onClick={() => router.push("/help")}>
                    <HelpCircle className="mr-2 h-4 w-4" />
                    <span>Yardım</span>
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="py-2" onClick={() => router.push("/auth/login")}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Oturumu kapat</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-[#470b69]"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-x"
                >
                  <path d="M18 6 6 18" />
                  <path d="m6 6 12 12" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-menu"
                >
                  <line x1="4" x2="20" y1="12" y2="12" />
                  <line x1="4" x2="20" y1="6" y2="6" />
                  <line x1="4" x2="20" y1="18" y2="18" />
                </svg>
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="container px-4 py-3">
              <nav className="flex flex-col space-y-3">
                {["Ana Sayfa", "Ders İşlemleri", "Kütüphane", "Kazanımlar", "Konuşma Pratiği"].map((page) => (
                  <Link
                    key={page}
                    href="#"
                    className={`text-[#470b69] font-medium hover:text-[#a38fb2] transition-colors py-1 ${
                      activePage === page ? "font-bold" : ""
                    }`}
                    onClick={() => {
                      setActivePage(page)
                      setMobileMenuOpen(false)
                    }}
                  >
                    {page}
                  </Link>
                ))}
                <Button
                  variant="outline"
                  className="border-[#470b69] text-[#470b69] hover:bg-[#470b69] hover:text-white w-full mt-2"
                  onClick={() => router.push("/bonuses")}
                >
                  Bonusu Kapın
                </Button>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-sm text-gray-600">Öğrenciler:</span>
                  <div className="flex gap-2">
                    <Avatar className="cursor-pointer h-8 w-8" onClick={() => router.push("/student/asya")}>
                      <AvatarImage src="/placeholder.svg?height=32&width=32&text=A" alt="Asya" />
                      <AvatarFallback className="bg-[#a38fb2] text-white">A</AvatarFallback>
                    </Avatar>
                    <Avatar className="cursor-pointer h-8 w-8" onClick={() => router.push("/student/ertug")}>
                      <AvatarImage src="/placeholder.svg?height=32&width=32&text=E" alt="Ertuğ" />
                      <AvatarFallback className="bg-[#a38fb2] text-white">E</AvatarFallback>
                    </Avatar>
                  </div>
                </div>
              </nav>
            </div>
          </div>
        )}
      </header>

      <main className="container px-4 py-6 mx-auto md:px-6">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {/* Membership Section */}
          <Card className="col-span-full md:col-span-1 bg-white rounded-xl shadow-sm border-none">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg text-[#470b69]">Üyelik</CardTitle>
                <button
                  className="text-sm text-[#470b69] hover:text-[#a38fb2]"
                  onClick={() => setShowMembershipDetails(true)}
                >
                  Daha fazla gör →
                </button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-[#f5f2f4]">
                    <Calendar className="w-5 h-5 text-[#470b69]" />
                  </div>
                  <div>
                    <p className="text-lg text-muted-foreground">Kalan dersler</p>
                    <p className="text-2xl font-semibold text-[#470b69]">2</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-[#f5f2f4]">
                    <Clock className="w-5 h-5 text-[#470b69]" />
                  </div>
                  <div>
                    <p className="text-lg text-muted-foreground">Otomatik yenileme</p>
                    <p className="text-2xl font-semibold text-[#470b69]">10 Nis</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Homework Panel */}
          <Card className="col-span-full md:col-span-1 bg-white rounded-xl shadow-sm border-none">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-[#470b69]">Ödev</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Asya" />
                      <AvatarFallback className="bg-[#a38fb2] text-white">AS</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-[#470b69]">Asya</p>
                      <p className="text-sm text-muted-foreground">1 egzersiz tamamlayın</p>
                    </div>
                  </div>
                  <Button
                    className="bg-[#39ff14] hover:bg-[#39ff14]/80 text-[#470b69] font-medium"
                    onClick={() => router.push("/student/asya")}
                  >
                    Tamamla
                  </Button>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Ertuğ" />
                      <AvatarFallback className="bg-[#a38fb2] text-white">ER</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-[#470b69]">Ertuğ</p>
                      <p className="text-sm text-muted-foreground">Tüm egzersizler tamamlandı</p>
                    </div>
                  </div>
                  <Badge className="bg-[#a38fb2] text-white">Tamamlandı</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Call-to-Action Banner */}
          <Card className="col-span-full md:col-span-1 bg-gradient-to-r from-[#470b69] to-[#a38fb2] text-white rounded-xl shadow-sm border-none">
            <CardContent className="p-6">
              <div className="flex flex-col items-start gap-4">
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-white/20">
                    <MessageCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">Konuşma Grubu</h3>
                    <p className="text-sm text-white/80">Arkadaşlarınızla İngilizce pratik yapın</p>
                  </div>
                </div>
                <div className="flex -space-x-4">
                  {[1, 2, 3, 4].map((i) => (
                    <Avatar key={i} className="border-2 border-[#470b69]">
                      <AvatarImage src={`/placeholder.svg?height=40&width=40&text=${i}`} alt={`User ${i}`} />
                      <AvatarFallback className="bg-[#a38fb2] text-white">{i}</AvatarFallback>
                    </Avatar>
                  ))}
                </div>
                <Button className="bg-[#39ff14] hover:bg-[#39ff14]/80 text-[#470b69] font-medium">Üye ol</Button>
              </div>
            </CardContent>
          </Card>

          {/* Next Lesson Section */}
          <Card className="col-span-full bg-white rounded-xl shadow-sm border-none">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg text-[#470b69]">Sonraki Ders</CardTitle>
                <Link href="#" className="text-sm text-[#470b69] hover:text-[#a38fb2]">
                  Hepsini gör →
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <ScrollArea className="w-full whitespace-nowrap">
                  <div className="flex space-x-4 p-1">
                    {students.map((student) => (
                      <button
                        key={student}
                        onClick={() => setActiveStudent(student)}
                        className={`flex flex-col items-center space-y-1 ${
                          activeStudent === student ? "opacity-100" : "opacity-60"
                        }`}
                      >
                        <Avatar
                          className={`w-16 h-16 border-2 ${
                            activeStudent === student ? "border-[#39ff14]" : "border-transparent"
                          }`}
                        >
                          <AvatarImage
                            src={`/placeholder.svg?height=64&width=64&text=${student.charAt(0)}`}
                            alt={student}
                          />
                          <AvatarFallback className="bg-[#a38fb2] text-white text-xl">
                            {student.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium text-[#470b69]">{student}</span>
                      </button>
                    ))}

                    {/* Öğrenci ekleme butonu */}
                    <button
                      onClick={() => setShowAddStudentModal(true)}
                      className="flex flex-col items-center space-y-1"
                    >
                      <div className="w-16 h-16 rounded-full border-2 border-dashed border-[#a38fb2] flex items-center justify-center bg-[#f5f2f4]">
                        <Plus className="h-8 w-8 text-[#470b69]" />
                      </div>
                      <span className="text-sm font-medium text-[#470b69]">Ekle</span>
                    </button>
                  </div>
                  <ScrollBar orientation="horizontal" />
                </ScrollArea>
              </div>

              {activeStudent === "Asya" ? (
                <Card className="border border-[#a38fb2]/20 shadow-none">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src="/placeholder.svg?height=40&width=40&text=A" alt="April H" />
                            <AvatarFallback className="bg-[#a38fb2] text-white">AH</AvatarFallback>
                          </Avatar>
                          <CardTitle className="text-[#470b69] ml-2">9 Nis, 18:30</CardTitle>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="text-[#470b69]">
                            <MoreVertical className="w-5 h-5" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-56">
                          <DropdownMenuItem className="flex items-center gap-2 py-3 cursor-pointer">
                            <Trash2 className="h-5 w-5 text-gray-500" />
                            <div className="flex-1">
                              <span>Dersi iptal et</span>
                            </div>
                            <span className="text-green-500 text-xs">ücretsiz</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem className="flex items-center gap-2 py-3 cursor-pointer">
                            <MoveRight className="h-5 w-5 text-gray-500" />
                            <div className="flex-1">
                              <span>Dersi taşı</span>
                            </div>
                            <span className="text-green-500 text-xs">ücretsiz</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem className="flex items-center gap-2 py-3 cursor-pointer">
                            <LogIn className="h-5 w-5 text-gray-500" />
                            <div className="flex-1">
                              <span>Derse katıl</span>
                            </div>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <CardDescription className="ml-12">{activeStudent} ve April H</CardDescription>
                    <Link
                      href="#"
                      className="text-[#470b69] hover:text-[#a38fb2] font-medium text-base ml-12 mt-2 block"
                    >
                      Özet
                    </Link>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col md:flex-row gap-6">
                      {/* Left column - Timeline (50% width on md and larger) */}
                      <div className="w-full md:w-1/2 space-y-4">
                        <div className="flex gap-4">
                          <div className="flex flex-col items-center">
                            <div className="w-8 h-8 rounded-full bg-[#a38fb2] flex items-center justify-center text-white">
                              1
                            </div>
                            <div className="w-0.5 h-16 bg-[#a38fb2]/30 my-1"></div>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <div className="w-10 h-10 rounded-lg bg-[#f5f2f4] flex items-center justify-center">
                                <img src="/placeholder.svg?height=30&width=30&text=🥁" alt="Drum" className="w-8 h-8" />
                              </div>
                              <div>
                                <p className="text-xs text-[#a38fb2]">~5 dk</p>
                                <h4 className="font-medium text-[#470b69]">Isınma</h4>
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">
                              Video izleyin ve ısınma egzersizleri yapın.
                            </p>
                            <div className="mt-2">
                              <Button
                                size="sm"
                                className="bg-[#39ff14] hover:bg-[#39ff14]/80 text-[#470b69] font-medium w-full md:w-[60%]"
                              >
                                Başla
                              </Button>
                            </div>
                          </div>
                        </div>

                        <div className="flex gap-4">
                          <div className="flex flex-col items-center">
                            <div className="w-8 h-8 rounded-full bg-[#a38fb2] flex items-center justify-center text-white">
                              2
                            </div>
                            <div className="w-0.5 h-16 bg-[#a38fb2]/30 my-1"></div>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <div className="w-10 h-10 rounded-lg bg-[#f5f2f4] flex items-center justify-center">
                                <img
                                  src="/placeholder.svg?height=30&width=30&text=🐭"
                                  alt="Mouse"
                                  className="w-8 h-8"
                                />
                              </div>
                              <div>
                                <p className="text-xs text-[#a38fb2]">~25 dk</p>
                                <h4 className="font-medium text-[#470b69]">Ders</h4>
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">Ana ders bölümü</p>
                            <div className="mt-2">
                              <Button
                                size="sm"
                                className="bg-gray-300 hover:bg-gray-400 text-[#470b69] font-medium w-full md:w-[60%]"
                              >
                                Başla
                              </Button>
                            </div>
                          </div>
                        </div>

                        <div className="flex gap-4">
                          <div className="flex flex-col items-center">
                            <div className="w-8 h-8 rounded-full bg-[#a38fb2] flex items-center justify-center text-white">
                              3
                            </div>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <div className="w-10 h-10 rounded-lg bg-[#f5f2f4] flex items-center justify-center">
                                <img
                                  src="/placeholder.svg?height=30&width=30&text=✏️"
                                  alt="Pencil"
                                  className="w-8 h-8"
                                />
                              </div>
                              <div>
                                <p className="text-xs text-[#a38fb2]">~10 dk</p>
                                <h4 className="font-medium text-[#470b69]">Eğlenceli pratik</h4>
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">Eğlenceli pratik egzersizleri</p>
                            <div className="mt-2">
                              <Button
                                size="sm"
                                className="bg-gray-300 hover:bg-gray-400 text-[#470b69] font-medium w-full md:w-[60%]"
                              >
                                Başla
                              </Button>
                              <div className="mt-2">
                                <Button
                                  variant="outline"
                                  className="border-[#470b69] text-[#470b69] hover:bg-[#470b69] hover:text-white w-full md:w-[60%]"
                                >
                                  Takvime ekle
                                </Button>
                                <Link
                                  href="#"
                                  className="text-[#470b69] hover:text-[#a38fb2] text-sm font-medium block mt-2"
                                >
                                  + Ders planla
                                </Link>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Right column - Video placeholder (50% width on md and larger) */}
                      <div className="w-full md:w-1/2 flex items-start justify-center mt-4 md:mt-0">
                        <div className="w-full aspect-video bg-[#f5f2f4] rounded-xl flex items-center justify-center">
                          <Video className="w-12 h-12 text-[#a38fb2] opacity-50" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="border border-[#a38fb2]/20 shadow-none">
                  <CardContent className="pt-6 pb-4 flex flex-col items-center justify-center text-center">
                    <div className="w-16 h-16 rounded-full bg-[#f5f2f4] flex items-center justify-center mb-4">
                      <Calendar className="w-8 h-8 text-[#a38fb2]" />
                    </div>
                    <p className="text-lg font-medium text-[#470b69] mb-6">Bir sonraki ders henüz planlanmadı</p>
                    <Button
                      variant="outline"
                      className="mb-4 border-[#470b69] text-[#470b69] hover:bg-[#470b69] hover:text-white"
                    >
                      + Ders planla
                    </Button>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>

          {/* Recent Activities Section */}
          <Card className="col-span-full bg-white rounded-xl shadow-sm border-none">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-[#470b69]">Son Etkinlikler</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="border rounded-lg overflow-hidden">
                    <div className="p-4">
                      {/* Header with teacher and student info */}
                      <div className="flex items-center mb-3">
                        <Avatar className="mr-3">
                          <AvatarImage src={activity.teacherImageUrl} alt={activity.teacher} />
                          <AvatarFallback className="bg-[#a38fb2] text-white">
                            {activity.teacher.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">
                            Öğretmen <span className="text-[#470b69]">{activity.teacher}</span> ve{" "}
                            <span className="text-[#470b69]">{activity.student}</span>
                          </p>
                          <p className="text-xs text-gray-500">{activity.timeAgo}</p>
                        </div>
                      </div>

                      {/* Lesson title */}
                      <h3 className="text-[#470b69] font-medium mb-2">{activity.title}</h3>

                      {/* Lesson content */}
                      <p className="text-sm mb-3">{activity.content}</p>

                      {/* Areas of success */}
                      <div className="mb-3">
                        <div className="flex items-center gap-1 mb-1">
                          <Star className="h-4 w-4 text-[#470b69]" />
                          <h4 className="font-medium text-[#470b69]">Areas of success</h4>
                        </div>
                        <p className="text-sm text-gray-600">{activity.areasOfSuccess}</p>
                      </div>

                      {/* Teacher recommendations */}
                      <div className="mb-3">
                        <div className="flex items-center gap-1 mb-1">
                          <Target className="h-4 w-4 text-[#470b69]" />
                          <h4 className="font-medium text-[#470b69]">Teacher recommendations</h4>
                        </div>
                        <p className="text-sm text-gray-600">{activity.teacherRecommendations}</p>
                      </div>

                      {/* Read more link */}
                      <div className="mb-3">
                        <Link href={`/lesson/activity-${activity.id}`} className="text-[#470b69] text-sm font-medium">
                          ... daha fazla oku
                        </Link>
                      </div>

                      {/* Lesson image - centered */}
                      <div className="flex justify-center mb-3">
                        <img
                          src={activity.imageUrl || "/placeholder.svg"}
                          alt="Lesson Screenshot"
                          className="w-full max-w-md h-auto rounded-lg"
                        />
                      </div>

                      {/* Social interactions */}
                      <div className="flex items-center justify-between border-t pt-3">
                        <div className="flex items-center gap-1">{/* Like count removed */}</div>
                        <div className="flex items-center gap-3">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-[#470b69] text-sm hover:bg-[#470b69]/10"
                            onClick={() => handleLike(activity.id)}
                          >
                            <Heart
                              className={`h-4 w-4 mr-1 ${
                                likedActivities[activity.id] ? "text-red-500 fill-red-500" : "text-gray-400"
                              }`}
                            />
                            Beğen
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-[#470b69] text-sm hover:bg-[#470b69]/10"
                            onClick={() => handleShare(activity.shareUrl)}
                          >
                            <Share2 className="h-4 w-4 mr-1" />
                            Paylaş
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Social media promotion */}
                    <div className="bg-gray-50 p-3 flex items-center justify-center gap-2 border-t">
                      <div className="w-6 h-6 bg-[#470b69] rounded-full flex items-center justify-center">
                        <Share2 className="h-3 w-3 text-white" />
                      </div>
                      <button
                        className="text-sm font-medium cursor-pointer"
                        onClick={() => handleShare(activity.shareUrl)}
                      >
                        Sosyal medyada paylaşın ve ₺600 kazanın
                      </button>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger>
                            <HelpCircle className="h-4 w-4 text-gray-400" />
                          </TooltipTrigger>
                          <TooltipContent className="max-w-xs bg-gray-700 text-white p-2 text-xs">
                            Birisi üye olmak için sizin linkinizi kullandığında, ikimiz de bir ödül alacaksınız. Ayrıca,
                            harika hediyeler kazanma şansınızın olduğu özel yarışmalara dahil olacaksınız!
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Membership Details Dialog */}
      <MembershipDetails open={showMembershipDetails} onOpenChange={setShowMembershipDetails} />

      {/* Share Dialog */}
      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">Paylaş</DialogTitle>
          </DialogHeader>
          <div className="flex justify-center space-x-2 py-4">
            <button className="bg-[#3b5998] text-white p-3 rounded-full">
              <Facebook className="h-6 w-6" />
            </button>
            <button className="bg-[#1DA1F2] text-white p-3 rounded-full">
              <Twitter className="h-6 w-6" />
            </button>
            <button className="bg-[#0088cc] text-white p-3 rounded-full">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-send"
              >
                <path d="m22 2-7 20-4-9-9-4Z" />
                <path d="M22 2 11 13" />
              </svg>
            </button>
            <button className="bg-[#25D366] text-white p-3 rounded-full">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-message-circle"
              >
                <path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z" />
              </svg>
            </button>
            <button className="bg-[#0077B5] text-white p-3 rounded-full">
              <Linkedin className="h-6 w-6" />
            </button>
          </div>
          <div className="flex items-center space-x-2">
            <div className="grid flex-1 gap-2">
              <Input className="border-gray-300" value={currentShareUrl} readOnly />
            </div>
            <Button type="submit" size="sm" className="px-3" onClick={copyToClipboard}>
              <span>kopyala</span>
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Öğrenci Ekleme Modal */}
      <Dialog open={showAddStudentModal} onOpenChange={setShowAddStudentModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Öğrenci ekle</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex space-x-6">
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="gender-girl"
                  name="gender"
                  className="h-4 w-4 text-[#470b69] accent-[#470b69]"
                  checked={newStudentGender === "Kız"}
                  onChange={() => setNewStudentGender("Kız")}
                />
                <label htmlFor="gender-girl" className="text-sm font-medium">
                  Kız
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="gender-boy"
                  name="gender"
                  className="h-4 w-4 text-[#470b69] accent-[#470b69]"
                  checked={newStudentGender === "Erkek"}
                  onChange={() => setNewStudentGender("Erkek")}
                />
                <label htmlFor="gender-boy" className="text-sm font-medium">
                  Erkek
                </label>
              </div>
            </div>

            <div>
              <Input placeholder="İsim" value={newStudentName} onChange={(e) => setNewStudentName(e.target.value)} />
            </div>

            <div className="relative">
              <Input
                type="date"
                placeholder="Doğum tarihi"
                value={newStudentBirthdate}
                onChange={(e) => setNewStudentBirthdate(e.target.value)}
                className="w-full"
              />
            </div>

            <Button className="w-full bg-[#7c3aed] hover:bg-[#6d28d9] text-white" onClick={handleAddStudent}>
              Ücretsiz ders planla
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
